import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || 'default_secret_change_me';
const TOKEN_EXPIRY = '7d';

export interface TokenPayload {
  userId: number;
  username: string;
  hid: string;
  iat?: number;
  exp?: number;
}

export function generateToken(userId: number, username: string, hid: string): string {
  return jwt.sign({ userId, username, hid }, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
}

export function verifyToken(token: string): TokenPayload | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as TokenPayload;
    return decoded;
  } catch {
    return null;
  }
}

export function generateTempToken(hid: string): string {
  return jwt.sign({ hid, type: 'temp' }, JWT_SECRET, { expiresIn: '1h' });
}

export function verifyTempToken(token: string): { hid: string } | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    if (decoded.type === 'temp') {
      return { hid: decoded.hid };
    }
    return null;
  } catch {
    return null;
  }
}
