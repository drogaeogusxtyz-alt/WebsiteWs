import Database from 'better-sqlite3';
import { resolve } from 'path';
import bcrypt from 'bcryptjs';
import { randomBytes } from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

const DB_PATH = resolve(process.env.DB_PATH || './valley.db');

let db: Database.Database | null = null;

function getDb(): Database.Database {
  if (!db) {
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
  }
  return db;
}

export function initDatabase(): void {
  const database = getDb();

  database.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      apikey TEXT UNIQUE NOT NULL,
      credits INTEGER DEFAULT 100 NOT NULL,
      hid TEXT,
      ip TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME
    );

    CREATE TABLE IF NOT EXISTS projects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT CHECK(status IN ('in_progress', 'completed', 'planned')) DEFAULT 'planned',
      category TEXT CHECK(category IN ('project', 'api', 'base')) DEFAULT 'project',
      technologies TEXT,
      github_url TEXT,
      demo_url TEXT,
      image TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS api_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      apikey TEXT NOT NULL,
      endpoint TEXT NOT NULL,
      credits_used INTEGER DEFAULT 10,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS api_plans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      price REAL NOT NULL,
      requests_per_month INTEGER NOT NULL,
      features TEXT,
      popular INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS user_plans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      plan_id INTEGER NOT NULL,
      active INTEGER DEFAULT 1,
      started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      expires_at DATETIME
    );

    CREATE TABLE IF NOT EXISTS blocked_ips (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ip TEXT UNIQUE NOT NULL,
      hid TEXT,
      reason TEXT NOT NULL,
      blocked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      permanent INTEGER DEFAULT 1
    );

    CREATE INDEX IF NOT EXISTS idx_users_apikey ON users(apikey);
    CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_blocked_ips ON blocked_ips(ip);
    CREATE INDEX IF NOT EXISTS idx_api_requests_user ON api_requests(user_id);
    CREATE INDEX IF NOT EXISTS idx_api_requests_key ON api_requests(apikey);
  `);

  seedData();
}

function seedData(): void {
  const database = getDb();

  const count = database.prepare('SELECT COUNT(*) as count FROM projects').get() as { count: number };
  if (count.count === 0) {
    const insertProject = database.prepare(
      `INSERT INTO projects (title, description, status, category, technologies, github_url, demo_url) VALUES (?, ?, ?, ?, ?, ?, ?)`
    );

    const projects = [
      ['Valley API Gateway', 'Gateway centralizado para gerenciamento de APIs com autenticacao por API key e controle de creditos.', 'in_progress', 'api', JSON.stringify(['Node.js', 'WebSocket', 'SQLite']), 'https://github.com/valley/api-gateway', null],
      ['Data Valley Base', 'Base de dados distribuida para armazenamento de metricas e analytics em tempo real.', 'in_progress', 'base', JSON.stringify(['Rust', 'gRPC', 'Redis']), 'https://github.com/valley/data-base', null],
      ['Valley Auth System', 'Sistema de autenticacao com validacao de dispositivos e protecao contra acessos nao autorizados.', 'completed', 'project', JSON.stringify(['TypeScript', 'WebSocket', 'bcrypt']), null, 'https://auth.valley.dev'],
      ['Valley Dashboard', 'Painel de controle para visualizacao de uso de APIs, creditos e metricas.', 'completed', 'project', JSON.stringify(['React', 'D3.js', 'Tailwind']), null, 'https://dash.valley.dev'],
      ['Valley ML Engine', 'Motor de machine learning para analise preditiva de padroes de uso.', 'planned', 'project', JSON.stringify(['Python', 'TensorFlow', 'FastAPI']), null, null],
      ['Image Processing API', 'API de processamento de imagens com suporte a filtros, redimensionamento e OCR.', 'completed', 'api', JSON.stringify(['Python', 'OpenCV', 'Tesseract']), null, 'https://api.valley.dev/images'],
      ['Text Analysis API', 'API de analise de texto com NLP, sentiment analysis e extracao de entidades.', 'completed', 'api', JSON.stringify(['Python', 'spaCy', 'NLTK']), null, 'https://api.valley.dev/text'],
      ['Valley Analytics Base', 'Base de dados para armazenamento e consulta de dados analiticos.', 'in_progress', 'base', JSON.stringify(['ClickHouse', 'Kafka', 'Grafana']), null, null]
    ];

    for (const p of projects) {
      insertProject.run(p);
    }
  }

  const planCount = database.prepare('SELECT COUNT(*) as count FROM api_plans').get() as { count: number };
  if (planCount.count === 0) {
    const insertPlan = database.prepare(
      `INSERT INTO api_plans (name, description, price, requests_per_month, features, popular) VALUES (?, ?, ?, ?, ?, ?)`
    );

    const plans = [
      ['Free', '100 creditos iniciais. Ideal para testes e desenvolvimento.', 0, 10, JSON.stringify(['100 creditos', '10 requisicoes', 'Suporte comunitario', 'Acesso a APIs basicas']), 0],
      ['Starter', '1.000 creditos mensais para projetos em crescimento.', 19.90, 100, JSON.stringify(['1.000 creditos/mes', '100 requisicoes', 'Suporte por email', 'Acesso a todas APIs', 'Analytics basico']), 0],
      ['Pro', '10.000 creditos mensais com recursos avancados.', 49.90, 1000, JSON.stringify(['10.000 creditos/mes', '1.000 requisicoes', 'Suporte prioritario', 'Acesso a todas APIs', 'Analytics avancado', 'Webhooks']), 1],
      ['Enterprise', 'Creditos ilimitados para grandes aplicacoes.', 199.90, 10000, JSON.stringify(['Creditos ilimitados', '10.000 requisicoes', 'Suporte dedicado 24/7', 'Acesso a todas APIs', 'Analytics completo', 'Webhooks', 'SLA garantido', 'IP Whitelist']), 0]
    ];

    for (const p of plans) {
      insertPlan.run(p);
    }
  }
}

export function generateApiKey(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let key = 'valley_';
  const length = 13 + Math.floor(Math.random() * 6);
  for (let i = 0; i < length; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return key;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function userExists(username: string, email: string): { username: boolean; email: boolean } {
  const database = getDb();
  const userByName = database.prepare('SELECT id FROM users WHERE username = ?').get(username);
  const userByEmail = database.prepare('SELECT id FROM users WHERE email = ?').get(email);

  return {
    username: !!userByName,
    email: !!userByEmail
  };
}

export function createUser(username: string, email: string, password: string, hid: string, ip: string): any | null {
  const exists = userExists(username, email);
  if (exists.username || exists.email) return null;

  const hashedPassword = bcrypt.hashSync(password, 12);
  const apikey = generateApiKey();

  const database = getDb();
  const result = database.prepare(
    `INSERT INTO users (username, email, password, apikey, credits, hid, ip) VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(username, email, hashedPassword, apikey, 100, hid, ip);

  if (!result.lastInsertRowid) return null;

  return {
    id: Number(result.lastInsertRowid),
    username,
    email,
    apikey,
    credits: 100,
    hid,
    ip,
    created_at: new Date().toISOString()
  };
}

export function findUserByUsername(username: string): any | null {
  const database = getDb();
  return database.prepare('SELECT * FROM users WHERE username = ?').get(username) || null;
}

export function findUserById(id: number): any | null {
  const database = getDb();
  return database.prepare('SELECT id, username, email, apikey, credits, hid, ip, created_at FROM users WHERE id = ?').get(id) || null;
}

export function findUserByApiKey(apikey: string): any | null {
  const database = getDb();
  return database.prepare('SELECT id, username, email, apikey, credits, hid, ip, created_at FROM users WHERE apikey = ?').get(apikey) || null;
}

export function deductCredits(userId: number, amount: number): boolean {
  const user = findUserById(userId);
  if (!user || user.credits < amount) return false;

  const database = getDb();
  database.prepare('UPDATE users SET credits = credits - ? WHERE id = ?').run(amount, userId);
  return true;
}

export function getProjects(category?: string): any[] {
  const database = getDb();
  if (category) {
    return database.prepare('SELECT * FROM projects WHERE category = ? ORDER BY created_at DESC').all(category);
  }
  return database.prepare('SELECT * FROM projects ORDER BY created_at DESC').all();
}

export function getApiPlans(): any[] {
  const database = getDb();
  return database.prepare('SELECT * FROM api_plans ORDER BY price ASC').all();
}

export function logApiRequest(userId: number, apikey: string, endpoint: string): void {
  const database = getDb();
  database.prepare(
    'INSERT INTO api_requests (user_id, apikey, endpoint, credits_used) VALUES (?, ?, ?, ?)'
  ).run(userId, apikey, endpoint, 10);
}

export function updateLastLogin(userId: number): void {
  const database = getDb();
  database.prepare('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?').run(userId);
}
