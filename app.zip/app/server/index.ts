import { WebSocketServer, WebSocket } from 'ws';
import { createServer } from 'http';
import dotenv from 'dotenv';
import {
  initDatabase,
  findUserByUsername,
  findUserById,
  findUserByApiKey,
  createUser,
  getProjects,
  getApiPlans,
  deductCredits,
  updateLastLogin,
  logApiRequest,
  userExists
} from './db';
import { verifyToken, generateToken } from './auth';
import {
  isBlocked,
  blockIP,
  checkRateLimit,
  recordFailedAttempt,
  resetFailedAttempts,
  isDuplicateRequest,
  validateUsername,
  validateEmail,
  validatePassword,
  validateApiKey,
  sanitizeInput,
  validateDeviceInfo,
  validatePayload,
  validateMessageType
} from './security';
import type { WebSocketMessage, DeviceInfo } from '../src/types';

dotenv.config();

const WS_PORT = parseInt(process.env.WS_PORT || '3001');
const API_REQUEST_COST = parseInt(process.env.API_REQUEST_COST || '10');

interface ClientData {
  ws: WebSocket;
  ip: string;
  hid: string;
  deviceInfo: DeviceInfo | null;
  authenticated: boolean;
  userId: number | null;
  username: string | null;
  connectedAt: number;
  requestCount: number;
  failedAttempts: number;
  lastRequest: number;
}

const clients = new Map<WebSocket, ClientData>();

const server = createServer((req, res) => {
  const ip = getClientIP(req);

  if (isBlocked(ip)) {
    res.writeHead(502, { 'Content-Type': 'text/plain' });
    res.end('Bad Gateway');
    return;
  }

  if (req.url?.startsWith('/ws')) {
    res.writeHead(426, { 'Content-Type': 'text/plain' });
    res.end('Upgrade Required');
    return;
  }

  if (req.url?.startsWith('/api/') || req.url === '/api') {
    recordFailedAttempt(ip);
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
    return;
  }

  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Valley WebSocket Server');
});

const wss = new WebSocketServer({ server, path: '/ws' });

function getClientIP(req: any): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) {
    return String(forwarded).split(',')[0].trim();
  }
  return req.socket?.remoteAddress || 'unknown';
}

function getHIDFromHeaders(headers: any): string {
  const hid = headers['x-device-hid'] || headers['hid'];
  if (hid && typeof hid === 'string') {
    return hid;
  }
  return 'unknown_' + Math.random().toString(36).substring(2);
}

wss.on('connection', (ws: WebSocket, req: any) => {
  const ip = getClientIP(req);
  const hid = getHIDFromHeaders(req.headers);

  if (isBlocked(ip, hid)) {
    ws.close(1008, 'Blocked');
    return;
  }

  if (!checkRateLimit(ip)) {
    blockIP(ip, 'Rate limit exceeded on connection', hid);
    ws.close(1008, 'Rate limit');
    return;
  }

  const clientData: ClientData = {
    ws,
    ip,
    hid,
    deviceInfo: null,
    authenticated: false,
    userId: null,
    username: null,
    connectedAt: Date.now(),
    requestCount: 0,
    failedAttempts: 0,
    lastRequest: Date.now()
  };

  clients.set(ws, clientData);

  ws.on('message', async (data: Buffer) => {
    const client = clients.get(ws);
    if (!client) return;

    client.lastRequest = Date.now();
    client.requestCount++;

    if (isBlocked(client.ip, client.hid)) {
      ws.close(1008, 'Blocked');
      return;
    }

    if (!checkRateLimit(client.ip)) {
      blockIP(client.ip, 'Rate limit in WebSocket', client.hid);
      ws.close(1008, 'Rate limit');
      return;
    }

    let message: WebSocketMessage;
    try {
      message = JSON.parse(data.toString());
    } catch {
      sendError(ws, 'Invalid message format');
      recordFailedAttempt(client.ip, client.hid);
      return;
    }

    if (!message.type || !validateMessageType(message.type)) {
      sendError(ws, 'Invalid message type');
      recordFailedAttempt(client.ip, client.hid);
      return;
    }

    const payloadValidation = validatePayload(message.payload);
    if (!payloadValidation.valid) {
      sendError(ws, payloadValidation.error || 'Invalid payload');
      recordFailedAttempt(client.ip, client.hid);
      return;
    }

    if (message.type === 'auth_register') {
      handleRegister(ws, client, message);
      return;
    }

    if (message.type === 'auth_login') {
      handleLogin(ws, client, message);
      return;
    }

    if (message.type === 'auth_check') {
      handleAuthCheck(ws, client, message);
      return;
    }

    if (!client.authenticated) {
      sendError(ws, 'Not authenticated', 401);
      recordFailedAttempt(client.ip, client.hid);
      return;
    }

    if (message.deviceInfo) {
      if (!validateDeviceInfo(message.deviceInfo)) {
        sendError(ws, 'Invalid device info');
        recordFailedAttempt(client.ip, client.hid);
        return;
      }
      client.deviceInfo = message.deviceInfo;
    }

    const requestKey = `${client.ip}_${client.hid}_${message.type}_${JSON.stringify(message.payload || {})}`;
    if (isDuplicateRequest(requestKey)) {
      return;
    }

    switch (message.type) {
      case 'get_projects':
        handleGetProjects(ws, message);
        break;
      case 'get_apis':
        handleGetApis(ws);
        break;
      case 'get_plans':
        handleGetPlans(ws);
        break;
      case 'get_user_info':
        handleGetUserInfo(ws, client);
        break;
      case 'use_credits':
        handleUseCredits(ws, client, message);
        break;
      default:
        sendError(ws, 'Unknown action');
    }
  });

  ws.on('close', () => {
    clients.delete(ws);
  });

  ws.on('error', () => {
    clients.delete(ws);
  });
});

function sendMessage(ws: WebSocket, type: string, payload?: any): void {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type, payload, timestamp: Date.now() }));
  }
}

function sendError(ws: WebSocket, message: string, code?: number): void {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: 'error', payload: { message, code: code || 400 }, timestamp: Date.now() }));
  }
}

function handleRegister(ws: WebSocket, client: ClientData, message: WebSocketMessage): void {
  const { username, email, password, deviceInfo } = message.payload || {};

  if (!username || !email || !password) {
    sendError(ws, 'Missing required fields');
    recordFailedAttempt(client.ip, client.hid);
    return;
  }

  const sanitizedUsername = sanitizeInput(username);
  const sanitizedEmail = sanitizeInput(email);

  if (!validateUsername(sanitizedUsername)) {
    sendError(ws, 'Username must be 3-30 characters, letters and numbers only');
    recordFailedAttempt(client.ip, client.hid);
    return;
  }

  if (!validateEmail(sanitizedEmail)) {
    sendError(ws, 'Invalid email format');
    recordFailedAttempt(client.ip, client.hid);
    return;
  }

  if (!validatePassword(password)) {
    sendError(ws, 'Password must be at least 6 characters');
    recordFailedAttempt(client.ip, client.hid);
    return;
  }

  if (deviceInfo && !validateDeviceInfo(deviceInfo)) {
    sendError(ws, 'Invalid device information');
    recordFailedAttempt(client.ip, client.hid);
    return;
  }

  const hid = deviceInfo?.hid || client.hid;

  const exists = userExists(sanitizedUsername, sanitizedEmail);
  if (exists.username) {
    sendError(ws, 'Username already taken');
    return;
  }
  if (exists.email) {
    sendError(ws, 'Email already registered');
    return;
  }

  const duplicateKey = `register_${sanitizedUsername}_${sanitizedEmail}`;
  if (isDuplicateRequest(duplicateKey)) {
    return;
  }

  const user = createUser(sanitizedUsername, sanitizedEmail, password, hid, client.ip);

  if (!user) {
    sendError(ws, 'Failed to create account');
    return;
  }

  const token = generateToken(user.id, user.username, hid);
  client.authenticated = true;
  client.userId = user.id;
  client.username = user.username;

  resetFailedAttempts(client.ip);

  sendMessage(ws, 'auth_success', {
    token,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      apikey: user.apikey,
      credits: user.credits
    }
  });
}

function handleLogin(ws: WebSocket, client: ClientData, message: WebSocketMessage): void {
  const { username, password, deviceInfo } = message.payload || {};

  if (!username || !password) {
    sendError(ws, 'Missing username or password');
    recordFailedAttempt(client.ip, client.hid);
    return;
  }

  const sanitizedUsername = sanitizeInput(username);

  if (!validateUsername(sanitizedUsername)) {
    sendError(ws, 'Invalid username format');
    recordFailedAttempt(client.ip, client.hid);
    return;
  }

  const user = findUserByUsername(sanitizedUsername);

  if (!user) {
    sendError(ws, 'Invalid credentials');
    recordFailedAttempt(client.ip, client.hid);
    return;
  }

  const bcrypt = require('bcryptjs');
  const validPassword = bcrypt.compareSync(password, user.password);

  if (!validPassword) {
    sendError(ws, 'Invalid credentials');
    recordFailedAttempt(client.ip, client.hid);
    return;
  }

  const hid = deviceInfo?.hid || client.hid;
  const token = generateToken(user.id, user.username, hid);

  client.authenticated = true;
  client.userId = user.id;
  client.username = user.username;

  updateLastLogin(user.id);
  resetFailedAttempts(client.ip);

  sendMessage(ws, 'auth_success', {
    token,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      apikey: user.apikey,
      credits: user.credits
    }
  });
}

function handleAuthCheck(ws: WebSocket, client: ClientData, message: WebSocketMessage): void {
  const { token } = message.payload || {};

  if (!token) {
    sendMessage(ws, 'auth_required');
    return;
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    sendMessage(ws, 'auth_required');
    return;
  }

  const user = findUserById(decoded.userId);
  if (!user) {
    sendMessage(ws, 'auth_required');
    return;
  }

  client.authenticated = true;
  client.userId = user.id;
  client.username = user.username;

  sendMessage(ws, 'auth_success', {
    token,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      apikey: user.apikey,
      credits: user.credits
    }
  });
}

function handleGetProjects(ws: WebSocket, message: WebSocketMessage): void {
  const category = message.payload?.category;
  const projects = getProjects(category);
  sendMessage(ws, 'projects_data', { projects });
}

function handleGetApis(ws: WebSocket): void {
  const apis = [
    {
      id: 'img-process',
      name: 'Image Processing',
      description: 'Processamento de imagens com filtros, redimensionamento e OCR',
      method: 'WS',
      endpoint: 'api.img.process',
      parameters: ['image', 'operations'],
      auth_required: true
    },
    {
      id: 'text-analysis',
      name: 'Text Analysis',
      description: 'Analise de texto com NLP e sentiment analysis',
      method: 'WS',
      endpoint: 'api.text.analyze',
      parameters: ['text', 'language'],
      auth_required: true
    },
    {
      id: 'data-convert',
      name: 'Data Converter',
      description: 'Conversao entre formatos JSON, XML, CSV, YAML',
      method: 'WS',
      endpoint: 'api.data.convert',
      parameters: ['data', 'from_format', 'to_format'],
      auth_required: true
    },
    {
      id: 'geo-location',
      name: 'Geolocation',
      description: 'Informacoes de geolocalizacao e timezone',
      method: 'WS',
      endpoint: 'api.geo.info',
      parameters: ['ip_or_coords'],
      auth_required: false
    }
  ];
  sendMessage(ws, 'apis_data', { apis });
}

function handleGetPlans(ws: WebSocket): void {
  const plans = getApiPlans();
  sendMessage(ws, 'plans_data', { plans });
}

function handleGetUserInfo(ws: WebSocket, client: ClientData): void {
  if (!client.userId) return;

  const user = findUserById(client.userId);
  if (!user) {
    sendError(ws, 'User not found', 404);
    return;
  }

  sendMessage(ws, 'user_info', {
    id: user.id,
    username: user.username,
    email: user.email,
    apikey: user.apikey,
    credits: user.credits,
    ip: client.ip,
    hid: client.hid,
    created_at: user.created_at
  });
}

function handleUseCredits(ws: WebSocket, client: ClientData, message: WebSocketMessage): void {
  if (!client.userId) return;

  const { apikey, endpoint } = message.payload || {};

  if (!apikey || !endpoint) {
    sendError(ws, 'Missing apikey or endpoint');
    return;
  }

  if (!validateApiKey(apikey)) {
    sendError(ws, 'Invalid API key format');
    return;
  }

  const user = findUserByApiKey(apikey);
  if (!user || user.id !== client.userId) {
    sendError(ws, 'Invalid API key', 403);
    return;
  }

  const success = deductCredits(client.userId, API_REQUEST_COST);
  if (!success) {
    sendError(ws, 'Insufficient credits', 402);
    return;
  }

  logApiRequest(client.userId, apikey, endpoint);

  const updatedUser = findUserById(client.userId);

  sendMessage(ws, 'credits_used', {
    success: true,
    credits_used: API_REQUEST_COST,
    remaining_credits: updatedUser?.credits || 0,
    endpoint
  });
}

server.listen(WS_PORT, () => {
  console.log(`Valley WebSocket Server running on port ${WS_PORT}`);
  console.log(`Environment: ${process.env.ENV || 'development'}`);
});

try {
  initDatabase();
  console.log('Database initialized');
} catch (err) {
  console.error('Database initialization failed:', err);
}

process.on('SIGTERM', () => {
  wss.close(() => {
    server.close(() => {
      process.exit(0);
    });
  });
});
