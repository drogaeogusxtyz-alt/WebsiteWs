import { readFileSync, writeFileSync, existsSync } from 'fs';
import { createHash, randomBytes } from 'crypto';
import { resolve } from 'path';

const BLACKLIST_PATH = resolve('./blacklist.json');

interface Blacklist {
  blacklistedIPs: Record<string, { reason: string; blockedAt: string; hid?: string; permanent: boolean }>;
  blacklistedHIDs: Record<string, { reason: string; blockedAt: string; ip?: string; permanent: boolean }>;
}

let blacklistCache: Blacklist = { blacklistedIPs: {}, blacklistedHIDs: {} };
let lastLoad = 0;

function loadBlacklist(): Blacklist {
  const now = Date.now();
  if (now - lastLoad < 1000) return blacklistCache;
  
  try {
    if (existsSync(BLACKLIST_PATH)) {
      const data = readFileSync(BLACKLIST_PATH, 'utf-8');
      blacklistCache = JSON.parse(data);
    } else {
      blacklistCache = { blacklistedIPs: {}, blacklistedHIDs: {} };
    }
  } catch {
    blacklistCache = { blacklistedIPs: {}, blacklistedHIDs: {} };
  }
  lastLoad = now;
  return blacklistCache;
}

function saveBlacklist(): void {
  try {
    writeFileSync(BLACKLIST_PATH, JSON.stringify(blacklistCache, null, 2));
  } catch (err) {
    console.error('Failed to save blacklist:', err);
  }
}

loadBlacklist();

const rateLimitMap = new Map<string, { count: number; timestamps: number[]; failedAttempts: number }>();
const requestCache = new Map<string, number>();
const RATE_LIMIT_WINDOW = 60000;
const MAX_REQUESTS_PER_MINUTE = parseInt(process.env.MAX_REQUESTS_PER_MINUTE || '30');
const MAX_FAILED_ATTEMPTS = parseInt(process.env.MAX_FAILED_ATTEMPTS || '3');

export function isBlocked(ip: string, hid?: string): boolean {
  const bl = loadBlacklist();
  if (bl.blacklistedIPs[ip]?.permanent) return true;
  if (hid && bl.blacklistedHIDs[hid]?.permanent) return true;
  return false;
}

export function blockIP(ip: string, reason: string, hid?: string): void {
  const bl = loadBlacklist();
  bl.blacklistedIPs[ip] = {
    reason,
    blockedAt: new Date().toISOString(),
    hid,
    permanent: true
  };
  if (hid) {
    bl.blacklistedHIDs[hid] = {
      reason,
      blockedAt: new Date().toISOString(),
      ip,
      permanent: true
    };
  }
  saveBlacklist();
}

export function blockHID(hid: string, reason: string, ip?: string): void {
  const bl = loadBlacklist();
  bl.blacklistedHIDs[hid] = {
    reason,
    blockedAt: new Date().toISOString(),
    ip,
    permanent: true
  };
  saveBlacklist();
}

export function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(ip) || { count: 0, timestamps: [], failedAttempts: 0 };
  
  entry.timestamps = entry.timestamps.filter(t => now - t < RATE_LIMIT_WINDOW);
  
  if (entry.timestamps.length >= MAX_REQUESTS_PER_MINUTE) {
    return false;
  }
  
  entry.timestamps.push(now);
  rateLimitMap.set(ip, entry);
  return true;
}

export function recordFailedAttempt(ip: string, hid?: string): void {
  const entry = rateLimitMap.get(ip) || { count: 0, timestamps: [], failedAttempts: 0 };
  entry.failedAttempts++;
  rateLimitMap.set(ip, entry);
  
  if (entry.failedAttempts >= MAX_FAILED_ATTEMPTS) {
    blockIP(ip, 'Too many failed attempts', hid);
  }
}

export function resetFailedAttempts(ip: string): void {
  const entry = rateLimitMap.get(ip);
  if (entry) {
    entry.failedAttempts = 0;
    rateLimitMap.set(ip, entry);
  }
}

export function isDuplicateRequest(key: string): boolean {
  const now = Date.now();
  const lastTime = requestCache.get(key);
  
  if (lastTime && now - lastTime < 2000) {
    return true;
  }
  
  requestCache.set(key, now);
  
  if (requestCache.size > 10000) {
    const entries = Array.from(requestCache.entries());
    requestCache.clear();
    entries.slice(-5000).forEach(([k, v]) => requestCache.set(k, v));
  }
  
  return false;
}

const VALID_USERNAME_REGEX = /^[a-zA-Z0-9]+$/;
const VALID_EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const VALID_PASSWORD_REGEX = /^[a-zA-Z0-9!@#$%^&*+=]{6,}$/;
const VALID_APIKEY_REGEX = /^valley_[a-zA-Z0-9]{13,18}$/;
const VALID_TEXT_REGEX = /^[a-zA-Z0-9\s\-_]+$/;

export function validateUsername(username: string): boolean {
  return VALID_USERNAME_REGEX.test(username) && username.length >= 3 && username.length <= 30;
}

export function validateEmail(email: string): boolean {
  return VALID_EMAIL_REGEX.test(email) && email.length <= 100;
}

export function validatePassword(password: string): boolean {
  return VALID_PASSWORD_REGEX.test(password) && password.length >= 6 && password.length <= 100;
}

export function validateApiKey(apikey: string): boolean {
  return VALID_APIKEY_REGEX.test(apikey);
}

export function sanitizeInput(input: string): string {
  return input.replace(/[^a-zA-Z0-9\s\-_@.]/g, '').trim();
}

export function validateDeviceInfo(deviceInfo: any): boolean {
  if (!deviceInfo || typeof deviceInfo !== 'object') return false;
  if (!deviceInfo.hid || typeof deviceInfo.hid !== 'string') return false;
  if (deviceInfo.hid.length < 10 || deviceInfo.hid.length > 100) return false;
  if (!/^[a-zA-Z0-9_-]+$/.test(deviceInfo.hid)) return false;
  if (!deviceInfo.userAgent || typeof deviceInfo.userAgent !== 'string') return false;
  if (!deviceInfo.platform || typeof deviceInfo.platform !== 'string') return false;
  return true;
}

export function generateHID(): string {
  return 'valley_' + createHash('sha256')
    .update(randomBytes(32))
    .digest('hex')
    .substring(0, 32);
}

export function hashData(data: string): string {
  return createHash('sha256').update(data).digest('hex');
}

export function verifyOrigin(headers: any): boolean {
  return true;
}

export function validatePayload(payload: any): { valid: boolean; error?: string } {
  if (!payload || typeof payload !== 'object') {
    return { valid: false, error: 'Invalid payload format' };
  }
  
  for (const [key, value] of Object.entries(payload)) {
    if (typeof value === 'string') {
      if (value.includes('--') || value.includes(';') || value.includes('/*') || value.includes('*/')) {
        return { valid: false, error: 'Invalid characters in field: ' + key };
      }
    }
  }
  
  return { valid: true };
}

const allowedMessageTypes = [
  'auth_login', 'auth_register', 'auth_check',
  'get_projects', 'get_apis', 'get_plans',
  'use_credits', 'get_user_info',
  'admin_stats', 'admin_users'
];

export function validateMessageType(type: string): boolean {
  return allowedMessageTypes.includes(type);
}

export function cleanExpiredEntries(): void {
  const now = Date.now();
  for (const [ip, entry] of rateLimitMap.entries()) {
    if (now - entry.timestamps[entry.timestamps.length - 1] > RATE_LIMIT_WINDOW * 10) {
      rateLimitMap.delete(ip);
    }
  }
}

setInterval(cleanExpiredEntries, 60000);
