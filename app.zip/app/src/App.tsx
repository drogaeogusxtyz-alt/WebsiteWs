import { useState, useCallback, useEffect } from 'react';
import { useWebSocket } from '@/hooks/useWebSocket';
import Login from '@/sections/Login';
import Welcome from '@/sections/Welcome';
import Home from '@/sections/Home';
import Projects from '@/sections/Projects';
import APIs from '@/sections/APIs';
import Navbar from '@/sections/Navbar';
import Drawer from '@/sections/Drawer';
import type { WebSocketMessage, Project, ApiEndpoint } from '@/types';

type Page = 'home' | 'projects' | 'apis';

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [showWelcome, setShowWelcome] = useState(false);
  const [welcomeUser, setWelcomeUser] = useState('');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [projects, setProjects] = useState<Project[]>([]);
  const [apis, setApis] = useState<ApiEndpoint[]>([]);
  const [plans, setPlans] = useState<any[]>([]);

  const handleMessage = useCallback((message: WebSocketMessage) => {
    switch (message.type) {
      case 'auth_success':
        if (message.payload?.user) {
          setShowWelcome(true);
          setWelcomeUser(message.payload.user.username);
        }
        break;
      case 'projects_data':
        if (message.payload?.projects) {
          setProjects(message.payload.projects);
        }
        break;
      case 'apis_data':
        if (message.payload?.apis) {
          setApis(message.payload.apis);
        }
        break;
      case 'plans_data':
        if (message.payload?.plans) {
          setPlans(message.payload.plans);
        }
        break;
      case 'auth_required':
        setProjects([]);
        setApis([]);
        break;
    }
  }, []);

  const [wsState, wsActions] = useWebSocket(handleMessage);

  useEffect(() => {
    if (wsState.authenticated && projects.length === 0) {
      wsActions.getProjects();
      wsActions.getApis();
      wsActions.getPlans();
    }
  }, [wsState.authenticated]);

  const handleWelcomeComplete = useCallback(() => {
    setShowWelcome(false);
  }, []);

  const handleNavigate = useCallback((newPage: string) => {
    setPage(newPage as Page);
    if (newPage === 'projects') {
      wsActions.getProjects();
    } else if (newPage === 'apis') {
      wsActions.getApis();
      wsActions.getPlans();
    }
  }, [wsActions]);

  if (!wsState.authenticated) {
    return (
      <Login
        onLogin={wsActions.login}
        onRegister={wsActions.register}
        error={wsState.error}
        connecting={wsState.connecting}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-900">
      {showWelcome && (
        <Welcome username={welcomeUser} onComplete={handleWelcomeComplete} />
      )}

      <Navbar
        currentPage={page}
        onNavigate={handleNavigate}
        onToggleDrawer={() => setDrawerOpen(true)}
        username={wsState.user?.username || null}
      />

      <Drawer
        isOpen={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        user={wsState.user}
        onLogout={wsActions.disconnect}
      />

      {page === 'home' && <Home user={wsState.user} />}
      {page === 'projects' && <Projects projects={projects} onGetProjects={wsActions.getProjects} />}
      {page === 'apis' && (
        <APIs
          user={wsState.user}
          plans={plans}
          apis={apis}
          onGetApis={wsActions.getApis}
          onGetPlans={wsActions.getPlans}
        />
      )}
    </div>
  );
}
