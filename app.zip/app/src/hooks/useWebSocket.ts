import { useState, useEffect, useRef, useCallback } from 'react';
import type { WebSocketMessage, User, DeviceInfo } from '@/types';

interface WebSocketState {
  connected: boolean;
  authenticated: boolean;
  user: User | null;
  connecting: boolean;
  error: string | null;
}

interface WebSocketActions {
  login: (username: string, password: string) => void;
  register: (username: string, email: string, password: string) => void;
  checkAuth: (token: string) => void;
  getProjects: (category?: string) => void;
  getApis: () => void;
  getPlans: () => void;
  getUserInfo: () => void;
  useCredits: (apikey: string, endpoint: string) => void;
  disconnect: () => void;
}

type MessageHandler = (message: WebSocketMessage) => void;

const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:3001/ws';

function getDeviceHID(): string {
  const stored = localStorage.getItem('valley_hid');
  if (stored) return stored;
  
  const hid = 'valley_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  localStorage.setItem('valley_hid', hid);
  return hid;
}

function getDeviceInfo(): DeviceInfo {
  return {
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    hid: getDeviceHID()
  };
}

export function useWebSocket(
  onMessage?: MessageHandler
): [WebSocketState, WebSocketActions] {
  const wsRef = useRef<WebSocket | null>(null);
  const [state, setState] = useState<WebSocketState>({
    connected: false,
    authenticated: false,
    user: null,
    connecting: false,
    error: null
  });

  const messageQueue = useRef<WebSocketMessage[]>([]);
  const reconnectAttempts = useRef(0);
  const reconnectTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    if (wsRef.current?.readyState === WebSocket.CONNECTING) return;

    setState(prev => ({ ...prev, connecting: true, error: null }));

    try {
      const ws = new WebSocket(WS_URL);
      wsRef.current = ws;

      ws.onopen = () => {
        reconnectAttempts.current = 0;
        setState(prev => ({ ...prev, connected: true, connecting: false, error: null }));

        while (messageQueue.current.length > 0) {
          const msg = messageQueue.current.shift();
          if (msg) ws.send(JSON.stringify(msg));
        }

        const token = localStorage.getItem('valley_token');
        if (token) {
          ws.send(JSON.stringify({
            type: 'auth_check',
            payload: { token },
            deviceInfo: getDeviceInfo(),
            hid: getDeviceHID()
          }));
        }
      };

      ws.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);

          if (message.type === 'auth_success') {
            const token = message.payload?.token;
            const user = message.payload?.user;
            if (token) {
              localStorage.setItem('valley_token', token);
            }
            setState(prev => ({
              ...prev,
              authenticated: true,
              user: user || prev.user
            }));
          }

          if (message.type === 'auth_required') {
            localStorage.removeItem('valley_token');
            setState(prev => ({
              ...prev,
              authenticated: false,
              user: null
            }));
          }

          if (message.type === 'error') {
            setState(prev => ({ ...prev, error: message.payload?.message || 'Unknown error' }));
          }

          onMessage?.(message);
        } catch {
          console.error('Failed to parse message');
        }
      };

      ws.onclose = () => {
        setState(prev => ({ ...prev, connected: false, connecting: false }));
        wsRef.current = null;

        if (reconnectAttempts.current < 5) {
          const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
          reconnectAttempts.current++;
          reconnectTimeout.current = setTimeout(() => {
            connect();
          }, delay);
        }
      };

      ws.onerror = () => {
        setState(prev => ({
          ...prev,
          connected: false,
          connecting: false,
          error: 'Connection error'
        }));
      };
    } catch {
      setState(prev => ({ ...prev, connecting: false, error: 'Failed to connect' }));
    }
  }, [onMessage]);

  useEffect(() => {
    connect();
    return () => {
      if (reconnectTimeout.current) {
        clearTimeout(reconnectTimeout.current);
      }
      wsRef.current?.close();
    };
  }, [connect]);

  const send = useCallback((message: WebSocketMessage) => {
    const enrichedMessage = {
      ...message,
      hid: getDeviceHID(),
      deviceInfo: getDeviceInfo(),
      timestamp: Date.now()
    };

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(enrichedMessage));
    } else {
      messageQueue.current.push(enrichedMessage);
    }
  }, []);

  const login = useCallback((username: string, password: string) => {
    send({
      type: 'auth_login',
      payload: { username, password, deviceInfo: getDeviceInfo() }
    });
  }, [send]);

  const register = useCallback((username: string, email: string, password: string) => {
    send({
      type: 'auth_register',
      payload: { username, email, password, deviceInfo: getDeviceInfo() }
    });
  }, [send]);

  const checkAuth = useCallback((token: string) => {
    send({
      type: 'auth_check',
      payload: { token }
    });
  }, [send]);

  const getProjects = useCallback((category?: string) => {
    send({ type: 'get_projects', payload: { category } });
  }, [send]);

  const getApis = useCallback(() => {
    send({ type: 'get_apis' });
  }, [send]);

  const getPlans = useCallback(() => {
    send({ type: 'get_plans' });
  }, [send]);

  const getUserInfo = useCallback(() => {
    send({ type: 'get_user_info' });
  }, [send]);

  const useCredits = useCallback((apikey: string, endpoint: string) => {
    send({ type: 'use_credits', payload: { apikey, endpoint } });
  }, [send]);

  const disconnect = useCallback(() => {
    localStorage.removeItem('valley_token');
    wsRef.current?.close();
    setState({
      connected: false,
      authenticated: false,
      user: null,
      connecting: false,
      error: null
    });
  }, []);

  const actions: WebSocketActions = {
    login,
    register,
    checkAuth,
    getProjects,
    getApis,
    getPlans,
    getUserInfo,
    useCredits,
    disconnect
  };

  return [state, actions];
}

export default useWebSocket;
