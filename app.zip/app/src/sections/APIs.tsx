import { useEffect, useState } from 'react';
import { Zap, Key, Check, Crown, Star, Rocket, Building2, Copy, CheckCheck, Lock, Wifi, ArrowRight } from 'lucide-react';
import type { ApiEndpoint } from '@/types';

interface APIsProps {
  user: { apikey: string; credits: number } | null;
  plans: any[];
  apis: ApiEndpoint[];
  onGetApis: () => void;
  onGetPlans: () => void;
}

export default function APIs({ user, plans, apis, onGetApis, onGetPlans }: APIsProps) {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'endpoints' | 'plans'>('endpoints');
  const [visibleItems, setVisibleItems] = useState(0);

  useEffect(() => {
    onGetApis();
    onGetPlans();
  }, [onGetApis, onGetPlans]);

  useEffect(() => {
    setVisibleItems(0);
    const timer = setTimeout(() => {
      setVisibleItems(activeTab === 'endpoints' ? apis.length : plans.length);
    }, 100);
    return () => clearTimeout(timer);
  }, [activeTab, apis.length, plans.length]);

  const copyApiKey = () => {
    if (user?.apikey) {
      navigator.clipboard.writeText(user.apikey);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const planIcons: Record<string, React.ReactNode> = {
    Free: <Star className="w-6 h-6" />,
    Starter: <Rocket className="w-6 h-6" />,
    Pro: <Crown className="w-6 h-6" />,
    Enterprise: <Building2 className="w-6 h-6" />
  };

  const planColors: Record<string, string> = {
    Free: 'from-slate-500 to-slate-600',
    Starter: 'from-blue-500 to-blue-600',
    Pro: 'from-purple-500 to-indigo-600',
    Enterprise: 'from-amber-500 to-orange-600'
  };

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8" style={{ background: 'linear-gradient(180deg, #0f172a 0%, #1e293b 100%)' }}>
      <div className="max-w-6xl mx-auto">
        <div className="mb-10" style={{ animation: 'fadeInDown 0.6s ease-out' }}>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-white shadow-lg">
              <Zap className="w-5 h-5" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-white">
              APIs<span className="text-purple-400">.</span>
            </h1>
          </div>
          <p className="text-slate-400 max-w-xl">Endpoints disponíveis e planos de acesso com sua API Key</p>
        </div>

        {user && (
          <div
            className="mb-8 p-5 rounded-2xl border border-purple-500/20 bg-purple-500/[0.03]"
            style={{ animation: 'fadeInUp 0.5s ease-out 0.1s both' }}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-white shadow-lg">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">Sua API Key</p>
                  <p className="text-white font-mono text-sm">{user.apikey}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="px-4 py-2 rounded-xl bg-white/5 border border-white/10">
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">Créditos</p>
                  <p className="text-purple-400 font-semibold">{user.credits} <span className="text-slate-500 font-normal text-xs">/ 100</span></p>
                </div>
                <button
                  onClick={copyApiKey}
                  className="px-4 py-2.5 rounded-xl bg-purple-500 hover:bg-purple-600 text-white text-sm font-medium transition-all duration-300 flex items-center gap-2 shadow-lg shadow-purple-500/20"
                >
                  {copied ? <CheckCheck className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copiado' : 'Copiar'}
                </button>
              </div>
            </div>
            <div className="mt-4 flex items-center gap-2 text-xs text-slate-500">
              <Lock className="w-3 h-3" />
              <span>Cada requisição consome 10 créditos</span>
            </div>
          </div>
        )}

        <div
          className="flex gap-2 mb-8 p-1 bg-white/5 rounded-xl w-fit"
          style={{ animation: 'fadeInUp 0.5s ease-out 0.2s both' }}
        >
          <button
            onClick={() => setActiveTab('endpoints')}
            className={`px-5 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
              activeTab === 'endpoints'
                ? 'bg-purple-500 text-white shadow-lg shadow-purple-500/25'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2">
              <Wifi className="w-4 h-4" />
              Endpoints
            </span>
          </button>
          <button
            onClick={() => setActiveTab('plans')}
            className={`px-5 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
              activeTab === 'plans'
                ? 'bg-purple-500 text-white shadow-lg shadow-purple-500/25'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2">
              <Crown className="w-4 h-4" />
              Planos
            </span>
          </button>
        </div>

        {activeTab === 'endpoints' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {apis.map((api, index) => (
              <div
                key={api.id}
                className={`p-5 rounded-2xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.06] hover:border-purple-500/20 transition-all duration-500 group ${
                  index < visibleItems ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                }`}
                style={{ transitionDelay: `${index * 80}ms` }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500/20 to-indigo-500/20 flex items-center justify-center text-purple-400 group-hover:from-purple-500 group-hover:to-indigo-500 group-hover:text-white transition-all duration-300">
                      <Zap className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold">{api.name}</h3>
                      <p className="text-slate-500 text-xs">{api.endpoint}</p>
                    </div>
                  </div>
                  <span className={`px-2 py-1 rounded-lg text-[10px] font-medium ${
                    api.auth_required
                      ? 'bg-amber-400/10 text-amber-400 border border-amber-400/20'
                      : 'bg-emerald-400/10 text-emerald-400 border border-emerald-400/20'
                  }`}>
                    {api.auth_required ? 'Auth' : 'Public'}
                  </span>
                </div>
                <p className="text-slate-400 text-sm mb-4">{api.description}</p>
                <div className="flex flex-wrap gap-1.5">
                  {api.parameters.map(param => (
                    <span key={param} className="px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 text-[10px] font-mono border border-purple-500/20">
                      {param}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'plans' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {plans.map((plan, index) => {
              const features = JSON.parse(plan.features || '[]');
              const isPopular = plan.popular === 1;

              return (
                <div
                  key={plan.id}
                  className={`relative p-5 rounded-2xl border transition-all duration-500 group ${
                    isPopular
                      ? 'border-purple-500/30 bg-purple-500/[0.04] hover:border-purple-500/50'
                      : 'border-white/5 bg-white/[0.02] hover:bg-white/[0.06] hover:border-white/15'
                  } ${index < visibleItems ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
                  style={{ transitionDelay: `${index * 100}ms` }}
                >
                  {isPopular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 text-white text-[10px] font-semibold shadow-lg">
                      Mais Popular
                    </div>
                  )}

                  <div className="mb-4">
                    <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${planColors[plan.name] || 'from-slate-500 to-slate-600'} flex items-center justify-center text-white mb-3 shadow-lg`}>
                      {planIcons[plan.name] || <Star className="w-5 h-5" />}
                    </div>
                    <h3 className="text-white font-semibold text-lg">{plan.name}</h3>
                    <p className="text-slate-400 text-xs mt-1">{plan.description}</p>
                  </div>

                  <div className="mb-4">
                    <span className="text-2xl font-bold text-white">
                      {plan.price === 0 ? 'Free' : `R$${plan.price.toFixed(2)}`}
                    </span>
                    {plan.price > 0 && <span className="text-slate-500 text-sm">/mês</span>}
                  </div>

                  <div className="space-y-2 mb-5">
                    {features.map((feature: string) => (
                      <div key={feature} className="flex items-center gap-2 text-sm">
                        <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                        <span className="text-slate-300">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <button
                    className={`w-full py-2.5 rounded-xl text-sm font-medium transition-all duration-300 flex items-center justify-center gap-2 ${
                      isPopular
                        ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40'
                        : 'bg-white/5 text-slate-300 hover:bg-white/10 border border-white/10'
                    }`}
                  >
                    {plan.price === 0 ? 'Começar' : 'Assinar'}
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <style>{`
        @keyframes fadeInDown {
          from { opacity: 0; transform: translateY(-15px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
