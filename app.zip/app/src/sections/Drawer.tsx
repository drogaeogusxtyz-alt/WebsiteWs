import { useEffect, useState } from 'react';
import {
  X, Github, Twitter, Linkedin, Mail, Globe, Code2, Shield, Zap, Database, Terminal, ChevronRight, ExternalLink
} from 'lucide-react';

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  user: { username: string; email: string; apikey: string; credits: number } | null;
  onLogout: () => void;
}

interface NavItem {
  label: string;
  icon: React.ReactNode;
  href: string;
  external?: boolean;
}

const socialLinks: NavItem[] = [
  { label: 'GitHub', icon: <Github className="w-4 h-4" />, href: 'https://github.com', external: true },
  { label: 'Twitter', icon: <Twitter className="w-4 h-4" />, href: 'https://twitter.com', external: true },
  { label: 'LinkedIn', icon: <Linkedin className="w-4 h-4" />, href: 'https://linkedin.com', external: true },
  { label: 'Email', icon: <Mail className="w-4 h-4" />, href: 'mailto:contato@valley.dev', external: true },
  { label: 'Website', icon: <Globe className="w-4 h-4" />, href: 'https://valley.dev', external: true },
];

const quickLinks = [
  { label: 'Documentação', icon: <Code2 className="w-4 h-4" />, href: '#' },
  { label: 'Status API', icon: <Zap className="w-4 h-4" />, href: '#' },
  { label: 'Base de Dados', icon: <Database className="w-4 h-4" />, href: '#' },
  { label: 'Terminal', icon: <Terminal className="w-4 h-4" />, href: '#' },
  { label: 'Segurança', icon: <Shield className="w-4 h-4" />, href: '#' },
];

export default function Drawer({ isOpen, onClose, user, onLogout }: DrawerProps) {
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setTimeout(() => setShowContent(true), 100);
    } else {
      document.body.style.overflow = '';
      setShowContent(false);
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const handleClose = () => {
    setShowContent(false);
    setTimeout(onClose, 300);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div
        className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${
          showContent ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={handleClose}
      />

      <div
        className={`absolute right-0 top-0 h-full w-80 max-w-[85vw] transition-transform duration-300 ease-out ${
          showContent ? 'translate-x-0' : 'translate-x-full'
        }`}
        style={{
          background: 'linear-gradient(180deg, #0f172a 0%, #1e293b 50%, #0f172a 100%)',
          boxShadow: '-4px 0 24px rgba(0,0,0,0.3)'
        }}
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-5 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
                <Shield className="w-4 h-4 text-white" />
              </div>
              <span className="text-white font-semibold">Valley</span>
            </div>
            <button
              onClick={handleClose}
              className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-all duration-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto py-4 px-4 space-y-1">
            {user && (
              <div className="mb-6 p-4 rounded-2xl bg-white/5 border border-white/10">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-indigo-500 flex items-center justify-center text-white font-bold text-sm">
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-medium text-sm truncate">{user.username}</p>
                    <p className="text-slate-400 text-xs truncate">{user.email}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Créditos</span>
                  <span className="text-blue-400 font-semibold">{user.credits}</span>
                </div>
                <div className="mt-2 p-2 rounded-lg bg-black/20">
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">API Key</p>
                  <p className="text-xs text-slate-300 font-mono truncate">{user.apikey}</p>
                </div>
              </div>
            )}

            <div className="mb-4">
              <p className="text-[10px] text-slate-500 uppercase tracking-wider px-3 mb-2">Redes Sociais</p>
              {socialLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/5 transition-all duration-200 group"
                >
                  <span className="text-slate-400 group-hover:text-blue-400 transition-colors">{link.icon}</span>
                  <span className="text-sm flex-1">{link.label}</span>
                  <ExternalLink className="w-3 h-3 text-slate-600 group-hover:text-slate-400 transition-colors" />
                </a>
              ))}
            </div>

            <div className="mb-4">
              <p className="text-[10px] text-slate-500 uppercase tracking-wider px-3 mb-2">Links Rápidos</p>
              {quickLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/5 transition-all duration-200 group"
                >
                  <span className="text-slate-400 group-hover:text-indigo-400 transition-colors">{link.icon}</span>
                  <span className="text-sm flex-1">{link.label}</span>
                  <ChevronRight className="w-3 h-3 text-slate-600 group-hover:text-slate-400 transition-colors" />
                </a>
              ))}
            </div>
          </div>

          <div className="p-4 border-t border-white/10">
            {user && (
              <button
                onClick={onLogout}
                className="w-full py-2.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 text-sm font-medium transition-all duration-200"
              >
                Sair da conta
              </button>
            )}
            <div className="mt-3 flex items-center justify-center gap-1 text-[10px] text-slate-600">
              <span>Valley v1.0</span>
              <span>•</span>
              <span>WebSocket</span>
              <span>•</span>
              <span>Secure</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
