import { useEffect, useState } from 'react';
import { MapPin, Wifi, Fingerprint, Key, User, CreditCard, Activity, Globe } from 'lucide-react';

interface HomeProps {
  user: { username: string; email: string; apikey: string; credits: number } | null;
}

interface ClientInfo {
  ip: string;
  hid: string;
  location: string;
  userAgent: string;
  platform: string;
  language: string;
  timezone: string;
}

export default function Home({ user }: HomeProps) {
  const [info, setInfo] = useState<ClientInfo | null>(null);
  const [visibleCards, setVisibleCards] = useState(0);

  useEffect(() => {
    const fetchIP = async () => {
      try {
        const res = await fetch('https://ipapi.co/json/');
        const data = await res.json();
        const hid = localStorage.getItem('valley_hid') || 'N/A';

        setInfo({
          ip: data.ip || '127.0.0.1',
          hid,
          location: `${data.city || 'Desconhecida'}, ${data.region || ''} - ${data.country_name || ''}`,
          userAgent: navigator.userAgent.substring(0, 60) + '...',
          platform: navigator.platform,
          language: navigator.language,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
        });
      } catch {
        setInfo({
          ip: '127.0.0.1',
          hid: localStorage.getItem('valley_hid') || 'N/A',
          location: 'Localização não disponível',
          userAgent: navigator.userAgent.substring(0, 60) + '...',
          platform: navigator.platform,
          language: navigator.language,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
        });
      }
    };

    fetchIP();
  }, []);

  useEffect(() => {
    if (info) {
      const timers = [0, 1, 2, 3, 4, 5].map(i =>
        setTimeout(() => setVisibleCards(prev => Math.max(prev, i + 1)), i * 150)
      );
      return () => timers.forEach(clearTimeout);
    }
  }, [info]);

  const cards = info ? [
    {
      label: 'Seu IP',
      value: info.ip,
      icon: <Wifi className="w-5 h-5" />,
      color: 'from-blue-500 to-blue-600',
      delay: 0
    },
    {
      label: 'HID do Dispositivo',
      value: info.hid.substring(0, 20) + '...',
      fullValue: info.hid,
      icon: <Fingerprint className="w-5 h-5" />,
      color: 'from-purple-500 to-purple-600',
      delay: 1
    },
    {
      label: 'Localização',
      value: info.location,
      icon: <MapPin className="w-5 h-5" />,
      color: 'from-emerald-500 to-emerald-600',
      delay: 2
    },
    {
      label: 'Username',
      value: user?.username || 'Convidado',
      icon: <User className="w-5 h-5" />,
      color: 'from-indigo-500 to-indigo-600',
      delay: 3
    },
    {
      label: 'API Key',
      value: user?.apikey ? user.apikey.substring(0, 20) + '...' : 'N/A',
      fullValue: user?.apikey,
      icon: <Key className="w-5 h-5" />,
      color: 'from-amber-500 to-amber-600',
      delay: 4
    },
    {
      label: 'Créditos',
      value: user?.credits !== undefined ? `${user.credits} créditos` : '0',
      icon: <CreditCard className="w-5 h-5" />,
      color: 'from-rose-500 to-rose-600',
      delay: 5
    }
  ] : [];

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8" style={{ background: 'linear-gradient(180deg, #0f172a 0%, #1e293b 100%)' }}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1
            className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-tight"
            style={{ animation: 'fadeInDown 0.8s ease-out' }}
          >
            Valley<span className="text-blue-400">.</span> Platform
          </h1>
          <p
            className="text-slate-400 text-lg max-w-2xl mx-auto"
            style={{ animation: 'fadeInDown 0.8s ease-out 0.2s both' }}
          >
            Sua plataforma completa de projetos, APIs e bases de dados. Explore, conecte e crie.
          </p>
        </div>

        <div
          className="mb-12 p-6 rounded-2xl border border-white/10 bg-white/[0.02]"
          style={{ animation: 'fadeInUp 0.6s ease-out 0.3s both' }}
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-white font-semibold text-lg">Informações do Dispositivo</h2>
              <p className="text-slate-400 text-sm">Dados coletados automaticamente</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {cards.map((card, index) => (
              <div
                key={card.label}
                className={`p-4 rounded-xl border border-white/5 bg-white/[0.03] hover:bg-white/[0.06] transition-all duration-300 group hover:border-white/10 ${
                  visibleCards > index ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                }`}
                style={{ transition: 'all 0.5s ease-out' }}
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${card.color} flex items-center justify-center text-white shadow-lg`}>
                    {card.icon}
                  </div>
                  <span className="text-slate-400 text-xs uppercase tracking-wider">{card.label}</span>
                </div>
                <p className="text-white font-mono text-sm truncate group-hover:text-blue-300 transition-colors">
                  {card.value}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              title: 'Projetos',
              description: 'Explore projetos em andamento, completos e planejados.',
              icon: <Globe className="w-6 h-6" />,
              color: 'from-blue-500 to-cyan-500',
              delay: 0.6
            },
            {
              title: 'APIs',
              description: 'Acesse APIs com sua key. 100 créditos inclusos.',
              icon: <Key className="w-6 h-6" />,
              color: 'from-purple-500 to-pink-500',
              delay: 0.8
            },
            {
              title: 'Bases',
              description: 'Bases de dados e infraestrutura dos projetos.',
              icon: <Fingerprint className="w-6 h-6" />,
              color: 'from-emerald-500 to-teal-500',
              delay: 1.0
            }
          ].map((item) => (
            <div
              key={item.title}
              className="p-6 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.06] transition-all duration-300 group cursor-pointer hover:border-white/20"
              style={{ animation: `fadeInUp 0.6s ease-out ${item.delay}s both` }}
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center text-white mb-4 shadow-lg group-hover:scale-110 transition-transform`}>
                {item.icon}
              </div>
              <h3 className="text-white font-semibold text-lg mb-2">{item.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">{item.description}</p>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes fadeInDown {
          from { opacity: 0; transform: translateY(-20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
