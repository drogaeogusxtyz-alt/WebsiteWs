import { useEffect, useState } from 'react';
import { FolderGit2, GitBranch, ExternalLink, Layers, Radio, CheckCircle2, Clock, Loader2 } from 'lucide-react';
import type { Project } from '@/types';

interface ProjectsProps {
  projects: Project[];
  onGetProjects: (category?: string) => void;
}

type FilterType = 'all' | 'project' | 'api' | 'base';
type StatusFilter = 'all' | 'in_progress' | 'completed' | 'planned';

export default function Projects({ projects, onGetProjects }: ProjectsProps) {
  const [categoryFilter, setCategoryFilter] = useState<FilterType>('all');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [visibleCards, setVisibleCards] = useState(0);

  useEffect(() => {
    onGetProjects();
  }, [onGetProjects]);

  useEffect(() => {
    setVisibleCards(0);
    const timer = setTimeout(() => {
      setVisibleCards(filteredProjects.length);
    }, 100);
    return () => clearTimeout(timer);
  }, [categoryFilter, statusFilter]);

  const filteredProjects = projects.filter(p => {
    if (categoryFilter !== 'all' && p.category !== categoryFilter) return false;
    if (statusFilter !== 'all' && p.status !== statusFilter) return false;
    return true;
  });

  const categoryLabels: Record<string, string> = {
    all: 'Todos',
    project: 'Projetos',
    api: 'APIs',
    base: 'Bases'
  };

  const statusConfig = {
    in_progress: { label: 'Em Andamento', icon: <Loader2 className="w-3 h-3" />, color: 'text-amber-400 bg-amber-400/10' },
    completed: { label: 'Completo', icon: <CheckCircle2 className="w-3 h-3" />, color: 'text-emerald-400 bg-emerald-400/10' },
    planned: { label: 'Planejado', icon: <Clock className="w-3 h-3" />, color: 'text-slate-400 bg-slate-400/10' }
  };

  const categoryIcons: Record<string, React.ReactNode> = {
    project: <FolderGit2 className="w-5 h-5" />,
    api: <Radio className="w-5 h-5" />,
    base: <Layers className="w-5 h-5" />
  };

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8" style={{ background: 'linear-gradient(180deg, #0f172a 0%, #1e293b 100%)' }}>
      <div className="max-w-6xl mx-auto">
        <div className="mb-10" style={{ animation: 'fadeInDown 0.6s ease-out' }}>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-3">
            Projetos<span className="text-blue-400">.</span>
          </h1>
          <p className="text-slate-400">Explore todos os projetos, APIs e bases de dados</p>
        </div>

        <div className="flex flex-wrap gap-3 mb-6" style={{ animation: 'fadeInUp 0.5s ease-out 0.2s both' }}>
          {(['all', 'project', 'api', 'base'] as FilterType[]).map(cat => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                categoryFilter === cat
                  ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/25'
                  : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {categoryLabels[cat]}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap gap-2 mb-8" style={{ animation: 'fadeInUp 0.5s ease-out 0.3s both' }}>
          {(['all', 'in_progress', 'completed', 'planned'] as StatusFilter[]).map(status => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-300 border ${
                statusFilter === status
                  ? 'border-blue-500/50 text-blue-400 bg-blue-500/10'
                  : 'border-white/5 text-slate-500 hover:text-slate-300 hover:border-white/10'
              }`}
            >
              {status === 'all' ? 'Todos' : statusConfig[status]?.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredProjects.map((project, index) => {
            const status = statusConfig[project.status];
            const techs = JSON.parse(project.technologies || '[]') as string[];

            return (
              <div
                key={project.id}
                className={`group p-5 rounded-2xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.06] hover:border-white/15 transition-all duration-500 ${
                  index < visibleCards ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                }`}
                style={{ transitionDelay: `${index * 80}ms` }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500/20 to-indigo-500/20 flex items-center justify-center text-blue-400 group-hover:from-blue-500 group-hover:to-indigo-500 group-hover:text-white transition-all duration-300">
                    {categoryIcons[project.category] || <FolderGit2 className="w-5 h-5" />}
                  </div>
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium ${status.color}`}>
                    {status.icon}
                    {status.label}
                  </span>
                </div>

                <h3 className="text-white font-semibold text-base mb-2 group-hover:text-blue-300 transition-colors">
                  {project.title}
                </h3>
                <p className="text-slate-400 text-sm mb-4 leading-relaxed line-clamp-2">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-1.5 mb-4">
                  {techs.slice(0, 4).map((tech: string) => (
                    <span
                      key={tech}
                      className="px-2 py-0.5 rounded-md bg-white/5 text-slate-400 text-[10px] font-medium border border-white/5"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-3 pt-3 border-t border-white/5">
                  {project.github_url && (
                    <a
                      href={project.github_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-white transition-colors"
                    >
                      <GitBranch className="w-3 h-3" />
                      GitHub
                    </a>
                  )}
                  {project.demo_url && (
                    <a
                      href={project.demo_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-white transition-colors"
                    >
                      <ExternalLink className="w-3 h-3" />
                      Demo
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {filteredProjects.length === 0 && (
          <div className="text-center py-20">
            <FolderGit2 className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-500">Nenhum projeto encontrado com estes filtros</p>
          </div>
        )}
      </div>

      <style>{`
        @keyframes fadeInDown {
          from { opacity: 0; transform: translateY(-15px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
