import { useEffect, useState } from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';

interface WelcomeProps {
  username: string;
  onComplete: () => void;
}

export default function Welcome({ username, onComplete }: WelcomeProps) {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<'enter' | 'stay' | 'exit'>('enter');
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; size: number; delay: number }>>([]);

  useEffect(() => {
    const newParticles = Array.from({ length: 30 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: 2 + Math.random() * 6,
      delay: Math.random() * 3
    }));
    setParticles(newParticles);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setPhase('exit');
            setTimeout(onComplete, 800);
          }, 500);
          return 100;
        }
        return prev + 2;
      });
    }, 40);

    const stayTimer = setTimeout(() => setPhase('stay'), 500);

    return () => {
      clearInterval(interval);
      clearTimeout(stayTimer);
    };
  }, [onComplete]);

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center transition-all duration-800 ${
        phase === 'enter' ? 'opacity-0 scale-110' : phase === 'stay' ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
      }`}
      style={{ background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 40%, #0f172a 100%)' }}
    >
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {particles.map(p => (
          <div
            key={p.id}
            className="absolute rounded-full"
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              width: p.size,
              height: p.size,
              background: `linear-gradient(135deg, rgba(59,130,246,${0.2 + Math.random() * 0.4}), rgba(99,102,241,${0.2 + Math.random() * 0.4}))`,
              animation: `particleFloat ${4 + Math.random() * 4}s ease-in-out infinite`,
              animationDelay: `${p.delay}s`,
              filter: 'blur(1px)'
            }}
          />
        ))}
      </div>

      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(59,130,246,0.15) 0%, transparent 70%)',
            animation: 'breathe 4s ease-in-out infinite'
          }}
        />
        <div
          className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(99,102,241,0.12) 0%, transparent 70%)',
            animation: 'breathe 5s ease-in-out infinite',
            animationDelay: '1s'
          }}
        />
      </div>

      <div className="relative z-10 flex flex-col items-center text-center px-6">
        <div className="relative mb-8">
          <div
            className="w-28 h-28 rounded-3xl flex items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, #3b82f6, #6366f1, #8b5cf6)',
              boxShadow: '0 0 60px rgba(59,130,246,0.3), 0 0 120px rgba(99,102,241,0.15)',
              animation: 'logoFloat 3s ease-in-out infinite'
            }}
          >
            <Sparkles className="w-12 h-12 text-white" style={{ animation: 'sparkle 2s ease-in-out infinite' }} />
          </div>
          <div
            className="absolute -inset-4 rounded-3xl border border-blue-400/20"
            style={{ animation: 'ringPulse 2s ease-in-out infinite' }}
          />
        </div>

        <h1
          className="text-4xl md:text-5xl font-bold text-white mb-3 tracking-tight"
          style={{ animation: 'textReveal 0.8s ease-out forwards', opacity: 0 }}
        >
          Bem-vindo
        </h1>

        <div
          className="flex items-center gap-2 mb-8"
          style={{ animation: 'textReveal 0.8s ease-out 0.2s forwards', opacity: 0 }}
        >
          <span className="text-2xl md:text-3xl font-semibold text-blue-400">{username}</span>
          <Sparkles className="w-5 h-5 text-yellow-400" style={{ animation: 'sparkle 1.5s ease-in-out infinite' }} />
        </div>

        <p
          className="text-slate-400 text-sm mb-10 max-w-xs"
          style={{ animation: 'textReveal 0.8s ease-out 0.4s forwards', opacity: 0 }}
        >
          Sua plataforma de projetos e APIs está pronta para uso
        </p>

        <div
          className="w-64 h-1.5 bg-white/10 rounded-full overflow-hidden"
          style={{ animation: 'textReveal 0.8s ease-out 0.6s forwards', opacity: 0 }}
        >
          <div
            className="h-full rounded-full transition-all duration-100"
            style={{
              width: `${progress}%`,
              background: 'linear-gradient(90deg, #3b82f6, #6366f1, #8b5cf6)'
            }}
          />
        </div>

        <div
          className="mt-6 flex items-center gap-2 text-slate-500 text-sm"
          style={{ animation: 'textReveal 0.8s ease-out 0.8s forwards', opacity: 0 }}
        >
          <span>Carregando recursos</span>
          <ArrowRight className="w-3 h-3 animate-pulse" />
        </div>
      </div>

      <style>{`
        @keyframes particleFloat {
          0%, 100% { transform: translate(0, 0) scale(1); opacity: 0.4; }
          25% { transform: translate(30px, -30px) scale(1.2); opacity: 0.8; }
          50% { transform: translate(-20px, 20px) scale(0.8); opacity: 0.6; }
          75% { transform: translate(20px, 10px) scale(1.1); opacity: 0.7; }
        }
        @keyframes breathe {
          0%, 100% { transform: scale(1); opacity: 0.5; }
          50% { transform: scale(1.3); opacity: 0.8; }
        }
        @keyframes logoFloat {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-8px); }
        }
        @keyframes sparkle {
          0%, 100% { transform: scale(1) rotate(0deg); opacity: 1; }
          50% { transform: scale(1.1) rotate(5deg); opacity: 0.8; }
        }
        @keyframes ringPulse {
          0%, 100% { transform: scale(1); opacity: 0.3; }
          50% { transform: scale(1.1); opacity: 0.1; }
        }
        @keyframes textReveal {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
