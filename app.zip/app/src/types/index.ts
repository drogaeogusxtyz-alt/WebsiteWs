export interface User {
  id: number;
  username: string;
  email: string;
  apikey: string;
  credits: number;
  created_at: string;
  hid: string;
  ip: string;
}

export interface Project {
  id: number;
  title: string;
  description: string;
  status: 'in_progress' | 'completed' | 'planned';
  category: 'project' | 'api' | 'base';
  technologies: string;
  github_url?: string;
  demo_url?: string;
  created_at: string;
  updated_at: string;
  image?: string;
}

export interface ApiPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  requests_per_month: number;
  features: string[];
  popular?: boolean;
}

export interface ApiEndpoint {
  id: string;
  name: string;
  description: string;
  method: string;
  endpoint: string;
  parameters: string[];
  auth_required: boolean;
}

export interface WebSocketMessage {
  type: string;
  payload?: any;
  token?: string;
  hid?: string;
  timestamp?: number;
  deviceInfo?: DeviceInfo;
}

export interface DeviceInfo {
  userAgent: string;
  platform: string;
  language: string;
  screenWidth: number;
  screenHeight: number;
  timezone: string;
  hid: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  token: string | null;
}

export interface ClientInfo {
  ip: string;
  hid: string;
  userAgent: string;
  connectedAt: number;
  requestCount: number;
  failedAttempts: number;
  lastRequest: number;
  isBlocked: boolean;
}
