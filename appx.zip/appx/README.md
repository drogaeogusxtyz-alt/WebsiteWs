# 🏔️ Valley Project Hub

Sistema completo de exposição de projetos e APIs com WebSocket, segurança total e banco de dados JSON.

## 📱 Rodando no Termux

### 1. Instale o Node.js
```bash
pkg update
pkg install nodejs
```

### 2. Clone/Extraia o projeto
```bash
cd ~/valley-project
```

### 3. Instale as dependências
```bash
npm install
```

### 4. Configure o .env (opcional, já vem pré-configurado)
```bash
nano .env
```

### 5. Inicie o servidor
```bash
npm start
```

### 6. Acesse no navegador
```
http://localhost:3000
```

Ou no Termux mesmo:
```bash
termux-open-url http://localhost:3000
```

## 🔒 Segurança Implementada

- ✅ Validação no WebSocket (antes do Express)
- ✅ Blacklist de IP/HID em JSON
- ✅ Rate limiting por minuto/hora
- ✅ Proteção DDoS/DoS
- ✅ Apenas letras e números em campos de texto
- ✅ Proteção contra SQL Injection (não usa SQL, usa JSON)
- ✅ Proteção contra XSS (escape no frontend)
- ✅ Proteção contra IDOR (validação de sessão + HID)
- ✅ Proteção contra engenharia reversa (device fingerprint)
- ✅ Rotas /api/* bloqueadas diretamente
- ✅ Bloqueio de curl sem device info
- ✅ Mutex para race conditions
- ✅ Sem POST/GET visível no Network (tudo via WebSocket)
- ✅ Credenciais no .env
- ✅ Permissões 600 nos arquivos JSON

## 📁 Estrutura

```
valley-project/
├── server.js          # Servidor WebSocket + HTTP
├── .env               # Configurações sensíveis
├── package.json
├── data/
│   ├── users.json     # Usuários cadastrados
│   ├── blacklist.json # IPs/HIDs bloqueados
│   ├── sessions.json  # Sessões ativas
│   ├── projects.json  # Projetos
│   ├── apis.json      # APIs disponíveis
│   ├── requests.json  # Log de requisições
│   └── rate_limit.json # Rate limiting
└── public/
    ├── index.html     # SPA completa
    ├── css/
    │   └── style.css  # UI Sênior
    └── js/
        └── app.js     # Lógica frontend
```

## 🎨 Features

- Tela de login/registro com validação em tempo real
- GIF de boas-vindas animado (animações CSS fluidas)
- Drawer com redes sociais
- Dashboard com projetos, APIs e planos
- API Key por usuário (valley_ + 16 chars)
- Sistema de créditos (100 free, 10 por requisição)
- Device info (IP, HID, localização, username, API key)
- Animações leves e fluidas
- Design dark mode profissional

## ⚡ Comandos Úteis

```bash
# Ver logs
node server.js

# Matar processo na porta 3000
kill $(lsof -t -i:3000)
kill $(lsof -t -i:8080)

# Resetar banco de dados
rm data/*.json
npm start
```

## 🛡️ Altere antes de usar

Edite o `.env` e mude:
- `JWT_SECRET`
- `ADMIN_KEY`
- `ENCRYPTION_KEY`

---
**Feito para rodar 100% no Termux** 🚀
