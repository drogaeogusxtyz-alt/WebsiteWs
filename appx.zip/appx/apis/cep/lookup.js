/**
 * ViaCEP - Brazilian ZIP Code Lookup
 * No API key required. Returns full address from CEP.
 */

const axios = require('axios');

async function cepLookup(cep) {
    try {
        if (!cep) return { status: false, msg: 'CEP obrigatorio' };

        // Remove non-digits
        const cleanCep = cep.replace(/\D/g, '');
        if (cleanCep.length !== 8) {
            return { status: false, msg: 'CEP invalido. Use 8 digitos.' };
        }

        const res = await axios.get(`https://viacep.com.br/ws/${cleanCep}/json/`, {
            timeout: 10000
        });

        if (res.data.erro) {
            return { status: false, msg: 'CEP nao encontrado' };
        }

        return {
            status: true,
            cep: res.data.cep,
            logradouro: res.data.logradouro,
            complemento: res.data.complemento,
            bairro: res.data.bairro,
            localidade: res.data.localidade,
            uf: res.data.uf,
            ibge: res.data.ibge,
            ddd: res.data.ddd,
            fullAddress: `${res.data.logradouro}, ${res.data.bairro}, ${res.data.localidade} - ${res.data.uf}, ${res.data.cep}`
        };

    } catch (err) {
        return { status: false, msg: 'Erro: ' + err.message };
    }
}

module.exports = { cepLookup };