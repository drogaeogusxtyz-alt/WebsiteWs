/**
 * Domain Info - WHOIS + DNS + Screenshot metadata
 * No API key required. Uses public endpoints.
 */

const axios = require('axios');
const dns = require('dns').promises;

async function domainInfo(domain) {
    try {
        if (!domain) return { status: false, msg: 'Dominio obrigatorio' };

        const sanitized = domain.trim().replace(/^https?:\/\//, '').split('/')[0];

        const result = {
            status: true,
            domain: sanitized,
            dns: {},
            http: {},
            screenshot: {}
        };

        // DNS lookup
        try {
            const addresses = await dns.resolve4(sanitized);
            result.dns.aRecords = addresses;
        } catch(e) {
            result.dns.aRecords = [];
        }

        try {
            const mx = await dns.resolveMx(sanitized);
            result.dns.mxRecords = mx.map(r => ({ priority: r.priority, exchange: r.exchange }));
        } catch(e) {
            result.dns.mxRecords = [];
        }

        try {
            const txt = await dns.resolveTxt(sanitized);
            result.dns.txtRecords = txt.flat();
        } catch(e) {
            result.dns.txtRecords = [];
        }

        // HTTP check
        try {
            const start = Date.now();
            const res = await axios.get(`https://${sanitized}`, {
                timeout: 10000,
                maxRedirects: 5,
                validateStatus: () => true
            });
            result.http.status = res.status;
            result.http.statusText = res.statusText;
            result.http.responseTime = Date.now() - start;
            result.http.server = res.headers['server'] || 'Desconhecido';
            result.http.contentType = res.headers['content-type'];
            result.http.isUp = res.status >= 200 && res.status < 400;
            result.http.finalUrl = res.request.res.responseUrl || `https://${sanitized}`;
        } catch(e) {
            result.http.isUp = false;
            result.http.error = e.message;
        }

        // Screenshot URL (using microlink - no key for basic)
        result.screenshot.microlink = `https://api.microlink.io/?url=https://${sanitized}&screenshot=true&meta=false&embed=screenshot.url`;
        result.screenshot.thumbnail = `https://www.google.com/s2/favicons?domain=${sanitized}&sz=128`;

        // SSL info hint
        result.ssl = {
            checkUrl: `https://www.sslchecker.com/sslchecker?su=${sanitized}`,
            note: 'Use o link acima para verificar detalhes do certificado SSL'
        };

        return result;

    } catch (err) {
        return { status: false, msg: 'Erro: ' + err.message };
    }
}

module.exports = { domainInfo };