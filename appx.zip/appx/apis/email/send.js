const nodemailer = require('nodemailer');

async function sendEmail(data) {
    const { smtp, from, to, cc, bcc, subject, text, html, attachments } = data;

    const transporter = nodemailer.createTransport({
        host: smtp.host,
        port: smtp.port,
        secure: smtp.secure,
        auth: smtp.auth
    });

    const mailOptions = {
        from,
        to: to.split(',').map(s => s.trim()),
        subject,
        text: text || '',
        html: html || ''
    };

    if (cc) mailOptions.cc = cc.split(',').map(s => s.trim());
    if (bcc) mailOptions.bcc = bcc.split(',').map(s => s.trim());

    if (attachments && attachments.length > 0) {
        mailOptions.attachments = attachments.map(att => ({
            filename: att.filename,
            content: att.content,
            encoding: att.encoding || 'utf-8'
        }));
    }

    const info = await transporter.sendMail(mailOptions);
    return {
        success: true,
        messageId: info.messageId,
        accepted: info.accepted,
        rejected: info.rejected
    };
}

module.exports = { sendEmail };
