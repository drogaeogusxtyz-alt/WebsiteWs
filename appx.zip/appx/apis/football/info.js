const axios = require('axios');

async function footballInfo(query) {
    try {
        if (!query || query.trim().length === 0) {
            return { status: false, msg: 'Query vazia' };
        }

        const sanitizedQuery = query.trim().substring(0, 100);

        // Use Wikipedia API for football info
        const wikiUrl = `https://pt.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(sanitizedQuery.replace(/\s+/g, '_'))}`;

        const headers = {
            'User-Agent': 'ValleyBot/1.0 (contact@valley.dev)',
            'Accept': 'application/json'
        };

        let result = {
            status: true,
            query: sanitizedQuery,
            source: 'Wikipedia',
            info: null
        };

        try {
            const wikiRes = await axios.get(wikiUrl, { headers, timeout: 10000 });
            const data = wikiRes.data;

            result.info = {
                title: data.title,
                description: data.extract,
                image: data.thumbnail ? data.thumbnail.source : null,
                url: data.content_urls ? data.content_urls.desktop.page : null
            };
        } catch(e) {
            // Fallback to search
            const searchUrl = `https://pt.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(sanitizedQuery + ' futebol')}&format=json&origin=*`;
            const searchRes = await axios.get(searchUrl, { headers, timeout: 10000 });
            const searchResults = searchRes.data.query.search;

            if (searchResults && searchResults.length > 0) {
                const first = searchResults[0];
                result.info = {
                    title: first.title,
                    description: first.snippet.replace(/<[^>]+>/g, ''),
                    image: null,
                    url: `https://pt.wikipedia.org/wiki/${encodeURIComponent(first.title.replace(/\s+/g, '_'))}`
                };
            } else {
                return { status: false, msg: 'Nenhum resultado encontrado para: ' + sanitizedQuery };
            }
        }

        // Try to get additional stats from football-data.org (free tier)
        try {
            const fdHeaders = { 'X-Auth-Token': 'YOUR_API_KEY' };
            const teamsRes = await axios.get(
                `https://api.football-data.org/v4/teams?limit=100`, 
                { headers: fdHeaders, timeout: 5000 }
            );
            const teams = teamsRes.data.teams || [];
            const matched = teams.find(t => 
                t.name.toLowerCase().includes(sanitizedQuery.toLowerCase()) ||
                t.shortName.toLowerCase().includes(sanitizedQuery.toLowerCase())
            );

            if (matched) {
                result.team = {
                    name: matched.name,
                    shortName: matched.shortName,
                    founded: matched.founded,
                    venue: matched.venue,
                    website: matched.website,
                    crest: matched.crest
                };
            }
        } catch(e) {
            // Football-data not available, skip
        }

        return result;

    } catch (err) {
        return { status: false, msg: 'Erro: ' + err.message };
    }
}

module.exports = { footballInfo };