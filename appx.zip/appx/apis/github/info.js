/**
 * GitHub Info - Public repository and user data
 * No API key required for public endpoints (60 req/hour unauthenticated)
 */

const axios = require('axios');

async function githubInfo(query) {
    try {
        if (!query) return { status: false, msg: 'Username ou repo obrigatorio' };

        const sanitized = query.trim().replace(/[^a-zA-Z0-9\-\/._]/g, '');

        // Check if it's a repo (has slash) or just user
        const isRepo = sanitized.includes('/');

        const headers = {
            'User-Agent': 'ValleyBot/1.0',
            'Accept': 'application/vnd.github.v3+json'
        };

        if (isRepo) {
            // Repo info
            const [owner, repo] = sanitized.split('/');
            const res = await axios.get(`https://api.github.com/repos/${owner}/${repo}`, {
                headers, timeout: 10000
            });

            return {
                status: true,
                type: 'repository',
                name: res.data.full_name,
                description: res.data.description,
                stars: res.data.stargazers_count,
                forks: res.data.forks_count,
                language: res.data.language,
                openIssues: res.data.open_issues_count,
                createdAt: res.data.created_at,
                updatedAt: res.data.updated_at,
                url: res.data.html_url,
                cloneUrl: res.data.clone_url,
                topics: res.data.topics || [],
                license: res.data.license ? res.data.license.name : null,
                owner: {
                    login: res.data.owner.login,
                    avatar: res.data.owner.avatar_url,
                    url: res.data.owner.html_url
                }
            };
        } else {
            // User info
            const res = await axios.get(`https://api.github.com/users/${sanitized}`, {
                headers, timeout: 10000
            });

            return {
                status: true,
                type: 'user',
                login: res.data.login,
                name: res.data.name,
                bio: res.data.bio,
                avatar: res.data.avatar_url,
                url: res.data.html_url,
                publicRepos: res.data.public_repos,
                followers: res.data.followers,
                following: res.data.following,
                createdAt: res.data.created_at,
                location: res.data.location,
                blog: res.data.blog,
                company: res.data.company
            };
        }

    } catch (err) {
        if (err.response && err.response.status === 404) {
            return { status: false, msg: 'Usuario ou repositorio nao encontrado' };
        }
        return { status: false, msg: 'Erro: ' + err.message };
    }
}

module.exports = { githubInfo };