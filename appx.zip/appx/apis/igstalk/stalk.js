const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({ rejectUnauthorized: false });

async function igStalk(username) {
    try {
        // Método 1: API não oficial
        const response = await axios.get(
            `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`,
            {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36',
                    'X-IG-App-ID': '936619743392459',
                    'Cookie': 'csrftoken=dummy; ig_did=dummy'
                },
                timeout: 15000,
                httpsAgent,
                validateStatus: () => true
            }
        );

        if (response.data?.data?.user) {
            const u = response.data.data.user;
            return {
                status: true,
                resultado: {
                    usuario: u.username,
                    nome_completo: u.full_name || '',
                    biografia: u.biography || '',
                    seguidores: u.edge_followed_by?.count || u.follower_count || 0,
                    seguindo: u.edge_follow?.count || u.following_count || 0,
                    publicacoes: u.edge_owner_to_timeline_media?.count || u.media_count || 0,
                    foto_perfil: u.profile_pic_url_hd || u.profile_pic_url || '',
                    privado: u.is_private || false,
                    verificado: u.is_verified || false
                }
            };
        }

        return { status: false, msg: 'Perfil não encontrado' };
    } catch (err) {
        return { status: false, msg: err.message };
    }
}

module.exports = { igStalk };
