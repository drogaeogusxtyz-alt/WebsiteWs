const axios = require('axios');

async function kimiAsk(prompt) {
    try {
        if (!prompt || prompt.trim().length === 0) {
            return { status: false, msg: 'Prompt vazio' };
        }

        const sanitizedPrompt = prompt.trim().substring(0, 2000);

        // Use Moonshot/Kimi API
        const apiKey = process.env.KIMI_API_KEY || 'sk-dummy-key';

        const response = await axios.post(
            'https://api.moonshot.cn/v1/chat/completions',
            {
                model: 'moonshot-v1-8k',
                messages: [
                    { role: 'system', content: 'Voce e Kimi, uma IA util e amigavel. Responda em portugues do Brasil.' },
                    { role: 'user', content: sanitizedPrompt }
                ],
                temperature: 0.7,
                max_tokens: 2000
            },
            {
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json'
                },
                timeout: 30000
            }
        );

        const reply = response.data.choices[0].message.content;

        return {
            status: true,
            prompt: sanitizedPrompt,
            response: reply,
            model: 'moonshot-v1-8k',
            tokens: response.data.usage ? response.data.usage.total_tokens : null
        };

    } catch (err) {
        // Fallback: return a simulated response if API key not set
        if (err.response && err.response.status === 401) {
            return {
                status: true,
                prompt: sanitizedPrompt,
                response: `[Kimi AI - Modo Offline] Voce perguntou: "${sanitizedPrompt}"\n\nPara usar a API real da Kimi, configure a variavel de ambiente KIMI_API_KEY com sua chave da Moonshot AI. Obtenha em: https://platform.moonshot.ai/`,
                model: 'moonshot-v1-8k (offline)',
                note: 'Configure KIMI_API_KEY para respostas reais'
            };
        }
        return { status: false, msg: 'Erro: ' + err.message };
    }
}

module.exports = { kimiAsk };