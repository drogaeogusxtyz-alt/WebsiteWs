const axios = require('axios');
const fs = require('fs');
const path = require('path');

const outDir = path.join(__dirname, '..', '..', 'data', 'downloads');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

async function mediaFireDownload(url) {
    try {
        const response = await axios.get(url, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
            timeout: 15000
        });

        const html = response.data;
        const match = html.match(/href="(https:\/\/download[\d]+\.mediafire\.com\/[^"]+)"/);

        if (!match) return { status: false, msg: 'Link direto não encontrado' };

        const directLink = match[1];
        const fileName = path.basename(new URL(directLink).pathname) || `mediafire_${Date.now()}.zip`;
        const filePath = path.join(outDir, fileName);

        const download = await axios({
            method: 'GET',
            url: directLink,
            responseType: 'stream',
            timeout: 300000
        });

        const writer = fs.createWriteStream(filePath);
        download.data.pipe(writer);

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        const stats = fs.statSync(filePath);

        return {
            status: true,
            nome: fileName,
            url: `/downloads/${fileName}`,
            tamanho: stats.size,
            tamanhoFormatado: formatBytes(stats.size)
        };
    } catch (err) {
        return { status: false, msg: err.message };
    }
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

module.exports = { mediaFireDownload };
