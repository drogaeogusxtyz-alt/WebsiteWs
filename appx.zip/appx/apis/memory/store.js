const fs = require('fs');
const path = require('path');

const db = path.join(__dirname, '..', '..', 'data', 'memory.json');

if (!fs.existsSync(db)) {
    fs.writeFileSync(db, JSON.stringify({}));
}

function readDB() {
    return JSON.parse(fs.readFileSync(db, 'utf8'));
}

function writeDB(data) {
    fs.writeFileSync(db, JSON.stringify(data, null, 2));
}

function memorySave(user, key, value) {
    const data = readDB();
    if (!data[user]) data[user] = {};
    data[user][key] = value;
    writeDB(data);
    return { status: true, result: data[user] };
}

function memoryGet(user, key) {
    const data = readDB();
    if (!data[user]) return { status: false, msg: 'Usuário não encontrado' };
    return { status: true, result: data[user][key] };
}

module.exports = { memorySave, memoryGet };
