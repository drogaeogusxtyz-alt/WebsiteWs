const axios = require('axios');
const cheerio = require('cheerio');

async function pinterestDownload(url) {
    try {
        if (!url || !url.includes('pinterest')) {
            return { status: false, msg: 'URL do Pinterest invalida' };
        }

        const headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8'
        };

        const res = await axios.get(url, { headers, timeout: 15000 });
        const $ = cheerio.load(res.data);

        let title = $('h1').first().text().trim() || $('title').text().trim() || 'Pinterest Pin';
        let description = $('meta[name="description"]').attr('content') || '';

        // Extract video URL
        const videoMatch = res.data.match(/"url":"(https:\/\/v1\.pinimg\.com\/videos[^"]+)"/);
        const videoUrl = videoMatch ? videoMatch[1].replace(/\\/g, '/') : null;

        // Extract image URL
        const imageMatch = res.data.match(/"url":"(https:\/\/i\.pinimg\.com[^"]+\.(?:jpg|png|webp))"/);
        const imageUrl = imageMatch ? imageMatch[1].replace(/\\/g, '/') : null;

        // Parse JSON-LD
        const jsonLd = $('script[type="application/ld+json"]').html();
        let mediaUrl = null;
        let mediaType = 'image';

        if (jsonLd) {
            try {
                const data = JSON.parse(jsonLd);
                if (data.video && data.video.contentUrl) {
                    mediaUrl = data.video.contentUrl;
                    mediaType = 'video';
                } else if (data.image) {
                    mediaUrl = typeof data.image === 'string' ? data.image : data.image.url;
                    mediaType = 'image';
                }
            } catch(e) {}
        }

        if (!mediaUrl) {
            if (videoUrl) { mediaUrl = videoUrl; mediaType = 'video'; }
            else if (imageUrl) { mediaUrl = imageUrl; mediaType = 'image'; }
        }

        // Collect all images
        const images = [];
        $('img[src*="pinimg"]').each((i, el) => {
            const src = $(el).attr('src');
            if (src && !images.includes(src)) images.push(src);
        });

        if (!mediaUrl && images.length > 0) {
            mediaUrl = images[0];
            mediaType = 'image';
        }

        if (!mediaUrl) {
            return { status: false, msg: 'Nao foi possivel extrair a midia. Tente outra URL.' };
        }

        return {
            status: true,
            type: mediaType,
            title: title.substring(0, 200),
            description: description.substring(0, 500),
            url: mediaUrl,
            source: url,
            thumbnail: images.length > 1 ? images[1] : mediaUrl,
            allImages: images.slice(0, 10)
        };

    } catch (err) {
        return { status: false, msg: 'Erro ao processar: ' + err.message };
    }
}

module.exports = { pinterestDownload };