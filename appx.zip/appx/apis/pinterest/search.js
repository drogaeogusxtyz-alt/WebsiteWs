const axios = require('axios');

async function pinterestSearch(query) {
    try {
        if (!query || query.trim().length === 0) {
            return { status: false, msg: 'Query vazia' };
        }

        const sanitizedQuery = query.trim().substring(0, 100);
        const searchUrl = `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(sanitizedQuery)}`;

        const headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8'
        };

        const res = await axios.get(searchUrl, { headers, timeout: 15000 });

        const dataMatch = res.data.match(/<script id="initial-state" type="application\/json">(.+?)<\/script>/);

        if (!dataMatch) {
            return { status: false, msg: 'Nao foi possivel obter resultados' };
        }

        const data = JSON.parse(dataMatch[1]);
        const pins = [];

        const resources = data.resourceResponses || [];
        resources.forEach(resource => {
            const results = resource.response?.data?.results || [];
            results.forEach(pin => {
                if (pin.images && pin.images.orig) {
                    pins.push({
                        id: pin.id,
                        title: pin.title || pin.description || 'Sem titulo',
                        description: pin.description || '',
                        image: pin.images.orig.url,
                        link: `https://www.pinterest.com/pin/${pin.id}/`,
                        pinner: pin.pinner ? pin.pinner.full_name : 'Desconhecido'
                    });
                }
            });
        });

        return {
            status: true,
            query: sanitizedQuery,
            count: pins.length,
            pins: pins.slice(0, 20)
        };

    } catch (err) {
        return { status: false, msg: 'Erro na busca: ' + err.message };
    }
}

module.exports = { pinterestSearch };