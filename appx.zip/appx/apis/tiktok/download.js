const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

const outDir = path.join(__dirname, '..', '..', 'data', 'downloads');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

function execPromise(cmd) {
    return new Promise((resolve, reject) => {
        exec(cmd, { maxBuffer: 1024 * 1024 * 10, timeout: 300000 }, (err, stdout, stderr) => {
            if (err) reject({ err, stderr });
            else resolve(stdout);
        });
    });
}

async function tiktokDownload(url, tipo = 'video') {
    try {
        const tempId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
        const ext = tipo === 'audio' ? 'mp3' : 'mp4';
        const fileName = `${tempId}.${ext}`;
        const filePath = path.join(outDir, fileName);

        const metaJson = await execPromise(`yt-dlp --dump-single-json --no-download "${url}"`);
        const meta = JSON.parse(metaJson);

        const opts = tipo === 'audio'
            ? '-f bestaudio -x --audio-format mp3 --audio-quality 128K'
            : '-f "bv*+ba/best" --merge-output-format mp4';

        await execPromise(`yt-dlp ${opts} -o "${filePath}" --no-warnings "${url}"`);

        if (!fs.existsSync(filePath)) {
            const possiveis = fs.readdirSync(outDir).filter(f => f.startsWith(tempId));
            if (possiveis.length > 0) {
                fs.renameSync(path.join(outDir, possiveis[0]), filePath);
            } else {
                return { status: false, msg: 'Arquivo não foi criado' };
            }
        }

        const stats = fs.statSync(filePath);

        return {
            status: true,
            nome: fileName,
            url: `/downloads/${fileName}`,
            titulo: meta.title || 'Sem título',
            criador: meta.uploader || 'Desconhecido',
            duracao: meta.duration || 0,
            thumbnail: meta.thumbnail || '',
            tamanho: stats.size
        };
    } catch (e) {
        return { status: false, msg: e.err?.message || e.message };
    }
}

module.exports = { tiktokDownload };
