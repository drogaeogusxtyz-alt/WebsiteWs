const axios = require('axios');

async function qrGenerate(text) {
    try {
        if (!text || text.trim().length === 0) {
            return { status: false, msg: 'Texto vazio' };
        }

        const sanitizedText = text.trim().substring(0, 1000);

        // Use qrserver.com API (free, no key needed)
        const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(sanitizedText)}`;

        return {
            status: true,
            text: sanitizedText,
            qrUrl: qrUrl,
            downloadUrl: qrUrl,
            type: text.match(/^\\d{10,15}$/) ? 'whatsapp_number' : 'text'
        };

    } catch (err) {
        return { status: false, msg: 'Erro: ' + err.message };
    }
}

module.exports = { qrGenerate };