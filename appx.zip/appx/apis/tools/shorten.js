const axios = require('axios');

async function urlShorten(longUrl) {
    try {
        if (!longUrl || !longUrl.startsWith('http')) {
            return { status: false, msg: 'URL invalida' };
        }

        const sanitizedUrl = longUrl.trim().substring(0, 2000);

        // Try is.gd (free, no key)
        try {
            const res = await axios.get(
                `https://is.gd/create.php?format=json&url=${encodeURIComponent(sanitizedUrl)}`,
                { timeout: 10000 }
            );

            if (res.data && res.data.shorturl) {
                return {
                    status: true,
                    originalUrl: sanitizedUrl,
                    shortUrl: res.data.shorturl,
                    provider: 'is.gd'
                };
            }
        } catch(e) {
            // Fallback to tinyurl
            const tinyRes = await axios.get(
                `https://tinyurl.com/api-create.php?url=${encodeURIComponent(sanitizedUrl)}`,
                { timeout: 10000 }
            );

            if (tinyRes.data && tinyRes.data.startsWith('http')) {
                return {
                    status: true,
                    originalUrl: sanitizedUrl,
                    shortUrl: tinyRes.data,
                    provider: 'tinyurl'
                };
            }
        }

        return { status: false, msg: 'Nao foi possivel encurtar a URL' };

    } catch (err) {
        return { status: false, msg: 'Erro: ' + err.message };
    }
}

module.exports = { urlShorten };