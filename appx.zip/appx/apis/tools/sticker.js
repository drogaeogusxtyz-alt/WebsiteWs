const axios = require('axios');
const fs = require('fs');
const path = require('path');

async function stickerConvert(imageUrl) {
    try {
        if (!imageUrl || !imageUrl.startsWith('http')) {
            return { status: false, msg: 'URL de imagem invalida' };
        }

        // Download image
        const imgRes = await axios.get(imageUrl, { 
            responseType: 'arraybuffer', 
            timeout: 15000,
            headers: { 'User-Agent': 'ValleyBot/1.0' }
        });

        const inputBuffer = Buffer.from(imgRes.data);

        // Save original image
        const downloadsDir = path.join(__dirname, '..', '..', '..', 'data', 'downloads');
        if (!fs.existsSync(downloadsDir)) {
            fs.mkdirSync(downloadsDir, { recursive: true });
        }

        const fileName = `sticker_${Date.now()}.png`;
        const filePath = path.join(downloadsDir, fileName);
        fs.writeFileSync(filePath, inputBuffer);

        return {
            status: true,
            originalUrl: imageUrl,
            stickerUrl: `/downloads/${fileName}`,
            size: inputBuffer.length,
            format: 'png',
            note: 'Imagem salva. Para converter em WEBP sticker no Termux, instale: pkg install libwebp && cwebp input.png -o output.webp',
            termuxCommand: `cd ${downloadsDir} && cwebp ${fileName} -o sticker.webp`
        };

    } catch (err) {
        return { status: false, msg: 'Erro ao processar: ' + err.message };
    }
}

module.exports = { stickerConvert };