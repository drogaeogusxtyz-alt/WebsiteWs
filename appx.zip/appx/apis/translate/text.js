/**
 * MyMemory Translation API
 * No API key required for basic usage (1000 words/day free)
 */

const axios = require('axios');

async function translateText(text, sourceLang, targetLang) {
    try {
        if (!text) return { status: false, msg: 'Texto obrigatorio' };

        const sanitizedText = text.trim().substring(0, 500);
        const sl = (sourceLang || 'auto').toLowerCase();
        const tl = (targetLang || 'pt').toLowerCase();

        const res = await axios.get(
            `https://api.mymemory.translated.net/get?q=${encodeURIComponent(sanitizedText)}&langpair=${sl}|${tl}`,
            { timeout: 15000 }
        );

        if (res.data.responseStatus !== 200) {
            return { status: false, msg: res.data.responseDetails || 'Erro na traducao' };
        }

        return {
            status: true,
            originalText: sanitizedText,
            translatedText: res.data.responseData.translatedText,
            sourceLang: sl,
            targetLang: tl,
            match: res.data.responseData.match,
            alternatives: (res.data.matches || []).slice(0, 3).map(m => ({
                translation: m.translation,
                match: m.match
            }))
        };

    } catch (err) {
        return { status: false, msg: 'Erro: ' + err.message };
    }
}

module.exports = { translateText };