/**
 * Open-Meteo Weather API
 * No API key required. Free worldwide weather data.
 */

const axios = require('axios');

async function weatherInfo(city) {
    try {
        if (!city) return { status: false, msg: 'Cidade obrigatoria' };

        const sanitized = city.trim().substring(0, 100);

        // First geocode the city
        const geoRes = await axios.get(
            `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(sanitized)}&count=1&language=pt&format=json`,
            { timeout: 10000 }
        );

        if (!geoRes.data.results || geoRes.data.results.length === 0) {
            return { status: false, msg: 'Cidade nao encontrada' };
        }

        const location = geoRes.data.results[0];
        const lat = location.latitude;
        const lon = location.longitude;

        // Get weather
        const weatherRes = await axios.get(
            `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,sunrise,sunset&timezone=auto`,
            { timeout: 10000 }
        );

        const current = weatherRes.data.current;
        const daily = weatherRes.data.daily;

        // Weather code mapping
        const weatherCodes = {
            0: 'Ceu limpo', 1: 'Principalmente limpo', 2: 'Parcialmente nublado', 3: 'Nublado',
            45: 'Neblina', 48: 'Neblina com deposito de gelo',
            51: 'Chuvisco leve', 53: 'Chuvisco moderado', 55: 'Chuvisco intenso',
            61: 'Chuva leve', 63: 'Chuva moderada', 65: 'Chuva intensa',
            71: 'Neve leve', 73: 'Neve moderada', 75: 'Neve intensa',
            80: 'Pancadas de chuva leves', 81: 'Pancadas de chuva moderadas', 82: 'Pancadas de chuva intensas',
            95: 'Tempestade leve', 96: 'Tempestade com granizo leve', 99: 'Tempestade com granizo intenso'
        };

        return {
            status: true,
            location: {
                name: location.name,
                country: location.country,
                latitude: lat,
                longitude: lon
            },
            current: {
                temperature: current.temperature_2m,
                feelsLike: current.apparent_temperature,
                humidity: current.relative_humidity_2m,
                windSpeed: current.wind_speed_10m,
                precipitation: current.precipitation,
                isDay: current.is_day === 1,
                condition: weatherCodes[current.weather_code] || 'Desconhecido',
                weatherCode: current.weather_code
            },
            daily: {
                maxTemp: daily.temperature_2m_max[0],
                minTemp: daily.temperature_2m_min[0],
                sunrise: daily.sunrise[0],
                sunset: daily.sunset[0]
            },
            unit: 'Celsius'
        };

    } catch (err) {
        return { status: false, msg: 'Erro: ' + err.message };
    }
}

module.exports = { weatherInfo };