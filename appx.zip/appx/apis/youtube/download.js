const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

const outDir = path.join(__dirname, '..', '..', 'data', 'downloads');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

function execPromise(cmd) {
    return new Promise((resolve, reject) => {
        exec(cmd, { maxBuffer: 1024 * 1024 * 10, timeout: 300000 }, (err, stdout, stderr) => {
            if (err) reject({ err, stderr });
            else resolve(stdout);
        });
    });
}

async function getVideoId(query) {
    if (query.startsWith('http')) {
        const match = query.match(/v=([^&]+)/);
        return match ? match[1] : null;
    }
    const html = await axios.get('https://www.youtube.com/results?search_query=' + encodeURIComponent(query));
    const match = html.data.match(/"videoId":"([^"]+)"/);
    return match ? match[1] : null;
}

async function youtubeInfo(query) {
    try {
        const videoId = await getVideoId(query);
        if (!videoId) return { status: false, msg: 'Vídeo não encontrado' };

        const url = `https://www.youtube.com/watch?v=${videoId}`;
        const stdout = await execPromise(`yt-dlp --dump-json --no-download "${url}"`);
        const data = JSON.parse(stdout);

        return {
            status: true,
            videoId,
            titulo: data.title || 'Desconhecido',
            canal: data.channel || data.uploader || 'Desconhecido',
            duracao: formatDuration(data.duration),
            descricao: data.description || 'Sem descrição',
            thumbnail: data.thumbnail || `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`
        };
    } catch (e) {
        return { status: false, msg: e.message };
    }
}

async function youtubeDownload(query, tipo = 'audio') {
    try {
        const videoId = await getVideoId(query);
        if (!videoId) return { status: false, msg: 'Vídeo não encontrado' };

        const url = `https://www.youtube.com/watch?v=${videoId}`;
        const safe = query.replace(/[^a-z0-9\-]/gi, '_').substring(0, 50);
        const ext = tipo === 'audio' ? 'mp3' : 'mp4';
        const fileName = `${safe}_${videoId}.${ext}`;
        const filePath = path.join(outDir, fileName);

        const opts = tipo === 'audio'
            ? '-f bestaudio -x --audio-format mp3 --audio-quality 128K'
            : '-f "bestvideo[height<=720]+bestaudio/best[height<=720]" --merge-output-format mp4';

        await execPromise(`yt-dlp ${opts} -o "${filePath}" "${url}"`);

        if (!fs.existsSync(filePath)) {
            return { status: false, msg: 'Download falhou' };
        }

        const stats = fs.statSync(filePath);

        return {
            status: true,
            nome: fileName,
            url: `/downloads/${fileName}`,
            videoId,
            tamanho: stats.size
        };
    } catch (e) {
        return { status: false, msg: e.err?.message || e.message };
    }
}

function formatDuration(seconds) {
    if (!seconds) return 'N/A';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
    return `${m}:${s.toString().padStart(2,'0')}`;
}

module.exports = { youtubeInfo, youtubeDownload };
