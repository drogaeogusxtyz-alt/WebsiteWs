/**
 * VALLEY PROJECT HUB v2.0 - Frontend
 * WebSocket Client | SPA | APIs Funcionais | IP Duplo
 */

const WS_URL = 'ws://' + window.location.hostname + ':8080';
const DEVICE_INFO = generateDeviceInfo();
let ws = null;
let token = localStorage.getItem('valley_token') || null;
let currentUser = null;
let reconnectAttempts = 0;
let isAuthenticated = false;
let localIP = 'Detectando...';

// ==================== IP DUPLO: Local (Wi-Fi) + Público ====================
async function getLocalIP() {
    return new Promise((resolve) => {
        const pc = new RTCPeerConnection({ iceServers: [] });
        pc.createDataChannel('');

        pc.onicecandidate = (e) => {
            if (!e || !e.candidate) {
                resolve('Não detectado');
                return;
            }
            const ipMatch = /([0-9]{1,3}\.){3}[0-9]{1,3}/.exec(e.candidate.candidate);
            if (ipMatch) {
                const ip = ipMatch[0];
                if (ip.startsWith('192.168.') || ip.startsWith('10.') || ip.startsWith('172.')) {
                    resolve(ip);
                    pc.close();
                }
            }
        };

        pc.createOffer().then(o => pc.setLocalDescription(o));

        setTimeout(() => {
            resolve('Não detectado');
            try { pc.close(); } catch(e) {}
        }, 3000);
    });
}

async function getPublicIP() {
    try {
        const res = await fetch('https://api.ipify.org?format=json', { 
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        });
        const data = await res.json();
        return data.ip;
    } catch {
        return 'Indisponível';
    }
}

async function loadDeviceIPs() {
    const [local, public] = await Promise.all([getLocalIP(), getPublicIP()]);
    localIP = local;
    document.getElementById('dev-ip-local').textContent = local;
    document.getElementById('dev-ip-public').textContent = public;
}

// ==================== DEVICE FINGERPRINT ====================
function generateDeviceInfo() {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillText('ValleyFP_' + navigator.userAgent + screen.width + screen.height + screen.colorDepth + new Date().getTimezoneOffset(), 2, 2);

    const canvasData = canvas.toDataURL();
    let hash = 0;
    for (let i = 0; i < canvasData.length; i++) {
        const char = canvasData.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }

    const hid = Math.abs(hash).toString(16).padStart(64, '0');

    return {
        hid: hid,
        userAgent: navigator.userAgent.substring(0, 500),
        platform: navigator.platform || 'unknown',
        screen: screen.width + 'x' + screen.height + '@' + screen.colorDepth
    };
}

// ==================== WEBSOCKET ====================
function connectWebSocket() {
    if (ws && ws.readyState === WebSocket.OPEN) return;

    ws = new WebSocket(WS_URL);

    ws.onopen = () => {
        console.log('[VALLEY] WebSocket conectado');
        reconnectAttempts = 0;
        if (token) {
            send({ type: 'auth_check', token });
        }
    };

    ws.onmessage = (event) => {
        try {
            const data = JSON.parse(event.data);
            handleMessage(data);
        } catch (e) {
            console.error('[VALLEY] Erro ao parsear:', e);
        }
    };

    ws.onclose = () => {
        console.log('[VALLEY] WebSocket fechado');
        ws = null;
        if (reconnectAttempts < 10) {
            const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), 30000);
            reconnectAttempts++;
            setTimeout(connectWebSocket, delay);
        }
    };

    ws.onerror = (err) => {
        console.error('[VALLEY] WebSocket erro:', err);
    };
}

function send(data) {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        showToast('Conexão perdida. Reconectando...');
        connectWebSocket();
        return false;
    }
    if (data.type !== 'ping') {
        data.deviceInfo = DEVICE_INFO;
    }
    ws.send(JSON.stringify(data));
    return true;
}

// ==================== MESSAGE HANDLER ====================
function handleMessage(data) {
    switch (data.type) {
        case 'pong': break;
        case 'register_success':
            token = data.token;
            localStorage.setItem('valley_token', token);
            currentUser = data.user;
            isAuthenticated = true;
            showWelcome(data.user);
            break;
        case 'login_success':
            token = data.token;
            localStorage.setItem('valley_token', token);
            currentUser = data.user;
            isAuthenticated = true;
            showWelcome(data.user);
            break;
        case 'auth_check':
            if (data.authenticated) {
                currentUser = data.user;
                isAuthenticated = true;
                showApp();
            } else {
                token = null;
                localStorage.removeItem('valley_token');
                showLogin();
            }
            break;
        case 'user_info':
            currentUser = data.user;
            updateUserInfo();
            break;
        case 'projects':
            renderProjects(data.projects);
            break;
        case 'apis':
            renderApis(data.apis);
            break;
        case 'api_plans':
            renderPlans(data.plans);
            break;
        case 'api_used':
            currentUser.credits = data.creditsRemaining;
            updateUserInfo();
            showToast(`API usada! Créditos: ${data.creditsRemaining}`);
            break;
        case 'logout_success':
            token = null; currentUser = null; isAuthenticated = false;
            localStorage.removeItem('valley_token');
            showLogin();
            break;
        case 'device_ips':
            document.getElementById('dev-ip-public').textContent = data.publicIP || 'Indisponível';
            break;
        case 'error':
            handleError(data);
            break;
    }
}

function handleError(data) {
    const errorEl = document.getElementById('login-error') || document.getElementById('reg-error');
    if (errorEl) errorEl.textContent = data.msg || 'Erro';
    if (data.code === 'UNAUTHORIZED') {
        token = null;
        localStorage.removeItem('valley_token');
        showLogin();
    }
    showToast(data.msg || 'Erro', 'error');
}

// ==================== NAVIGAÇÃO ====================
function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
}

function showLogin() {
    showScreen('login-screen');
    document.getElementById('login-error').textContent = '';
    document.getElementById('reg-error').textContent = '';
}

function showWelcome(user) {
    showScreen('welcome-screen');
    document.getElementById('welcome-name').textContent = user.username;
    document.getElementById('welcome-credits').textContent = user.credits;
    document.getElementById('welcome-apikey').textContent = user.apiKey.substring(0, 12) + '...';
    animateCounters();
    setTimeout(() => showApp(), 2500);
}

function showApp() {
    showScreen('app-screen');
    updateUserInfo();
    loadDeviceInfo();
    send({ type: 'get_projects' });
    send({ type: 'get_apis' });
    send({ type: 'get_api_plans' });
    send({ type: 'get_user_info' });
}

// ==================== LOGIN / REGISTER ====================
document.getElementById('login-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    document.getElementById('login-error').textContent = '';
    if (!username || !password) {
        document.getElementById('login-error').textContent = 'Preencha todos os campos';
        return;
    }
    send({ type: 'auth_login', username, password });
});

document.getElementById('register-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('reg-username').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-password').value;
    document.getElementById('reg-error').textContent = '';
    if (!username || !email || !password) {
        document.getElementById('reg-error').textContent = 'Preencha todos os campos';
        return;
    }
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
        document.getElementById('reg-error').textContent = 'Username: apenas letras e números';
        return;
    }
    if (password.length < 6) {
        document.getElementById('reg-error').textContent = 'Senha mínimo 6 caracteres';
        return;
    }
    send({ type: 'auth_register', username, email, password });
});

document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const tab = btn.dataset.tab;
        document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
        document.getElementById(tab === 'login' ? 'login-form' : 'register-form').classList.add('active');
    });
});

// ==================== DRAWER ====================
const drawer = document.getElementById('drawer');
const drawerOverlay = document.getElementById('drawer-overlay');

function openDrawer() {
    drawer.classList.add('open');
    drawerOverlay.classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeDrawer() {
    drawer.classList.remove('open');
    drawerOverlay.classList.remove('open');
    document.body.style.overflow = '';
}

document.getElementById('menu-toggle').addEventListener('click', openDrawer);
document.getElementById('drawer-close').addEventListener('click', closeDrawer);
drawerOverlay.addEventListener('click', closeDrawer);

document.querySelectorAll('.drawer-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = link.dataset.page;
        document.querySelectorAll('.drawer-link').forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.getElementById('page-' + page).classList.add('active');
        closeDrawer();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});

// ==================== PAGES ====================
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        filterProjects(btn.dataset.filter);
    });
});

let allProjects = [];

function renderProjects(projects) {
    allProjects = projects;
    filterProjects('all');
}

function filterProjects(filter) {
    const grid = document.getElementById('projects-grid');
    grid.innerHTML = '';
    const filtered = filter === 'all' 
        ? allProjects 
        : allProjects.filter(p => p.status === filter || p.category === filter);

    filtered.forEach((proj, i) => {
        const card = document.createElement('div');
        card.className = 'project-card';
        card.style.animationDelay = (i * 0.05) + 's';
        card.style.animation = 'fadeIn 0.4s ease forwards';
        card.style.opacity = '0';

        const statusClass = proj.status === 'done' ? 'status-done' : 'status-progress';
        const statusText = proj.status === 'done' ? 'Concluído' : 'Em Andamento';

        card.innerHTML = `
            <span class="project-status ${statusClass}">${statusText}</span>
            <h3>${escapeHtml(proj.title)}</h3>
            <p>${escapeHtml(proj.desc)}</p>
            <div class="project-tech">
                ${proj.tech.map(t => `<span class="tech-tag">${escapeHtml(t)}</span>`).join('')}
            </div>
        `;
        grid.appendChild(card);
    });
}

function renderApis(apis) {
    const grid = document.getElementById('apis-grid');
    grid.innerHTML = '';

    apis.forEach((api, i) => {
        const card = document.createElement('div');
        card.className = 'api-card' + (api.premium ? ' premium' : '');
        card.style.animationDelay = (i * 0.05) + 's';
        card.style.animation = 'fadeIn 0.4s ease forwards';
        card.style.opacity = '0';

        card.innerHTML = `
            <span class="api-badge ${api.premium ? 'premium' : 'free'}">${api.premium ? 'Premium' : 'Free'}</span>
            <h3>${escapeHtml(api.name)}</h3>
            <p>${escapeHtml(api.desc)}</p>
            <div class="api-endpoint">${escapeHtml(api.endpoint)}</div>
            <button class="btn-api" data-api-id="${escapeHtml(api.id)}">Usar API</button>
        `;
        grid.appendChild(card);
    });

    grid.querySelectorAll('.btn-api').forEach(btn => {
        btn.addEventListener('click', () => {
            const apiId = btn.dataset.apiId;
            send({ type: 'use_api', apiId });
        });
    });
}

function renderPlans(plans) {
    const grid = document.getElementById('plans-grid');
    grid.innerHTML = '';

    plans.forEach((plan, i) => {
        const card = document.createElement('div');
        card.className = 'plan-card' + (plan.id === 'pro' ? ' featured' : '');
        card.style.animationDelay = (i * 0.05) + 's';
        card.style.animation = 'fadeIn 0.4s ease forwards';
        card.style.opacity = '0';

        card.innerHTML = `
            <div class="plan-name">${escapeHtml(plan.name)}</div>
            <div class="plan-price">$${plan.price}<span>/mês</span></div>
            <div class="plan-credits">${plan.credits} créditos · ${plan.requests} reqs</div>
            <ul class="plan-features">
                ${plan.features.map(f => `<li>${escapeHtml(f)}</li>`).join('')}
            </ul>
            <button class="btn-plan">Escolher Plano</button>
        `;
        grid.appendChild(card);
    });
}

// ==================== USER INFO & DEVICE ====================
function updateUserInfo() {
    if (!currentUser) return;

    document.getElementById('header-username').textContent = currentUser.username;
    document.getElementById('profile-name').textContent = currentUser.username;
    document.getElementById('profile-plan').textContent = currentUser.plan.toUpperCase();
    document.getElementById('profile-credits').textContent = currentUser.credits;
    document.getElementById('profile-apikey').textContent = currentUser.apiKey.substring(0, 12) + '...';
    document.getElementById('profile-plan-detail').textContent = currentUser.plan.toUpperCase();

    if (currentUser.createdAt) {
        const date = new Date(currentUser.createdAt);
        document.getElementById('profile-date').textContent = date.toLocaleDateString('pt-BR');
    }

    document.getElementById('dev-user').textContent = currentUser.username;
    document.getElementById('dev-apikey').textContent = currentUser.apiKey;
    document.getElementById('dev-credits').textContent = currentUser.credits;
    document.getElementById('dev-plan').textContent = currentUser.plan.toUpperCase();
}

function loadDeviceInfo() {
    // IP Local (Wi-Fi) via WebRTC
    getLocalIP().then(ip => {
        document.getElementById('dev-ip-local').textContent = ip;
    });

    // IP Público
    getPublicIP().then(ip => {
        document.getElementById('dev-ip-public').textContent = ip;
    });

    // HID
    document.getElementById('dev-hid').textContent = DEVICE_INFO.hid.substring(0, 16) + '...';

    // Localização
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            pos => {
                const lat = pos.coords.latitude.toFixed(3);
                const lon = pos.coords.longitude.toFixed(3);
                document.getElementById('dev-loc').textContent = `${lat}, ${lon}`;
            },
            () => { document.getElementById('dev-loc').textContent = 'Não disponível'; }
        );
    } else {
        document.getElementById('dev-loc').textContent = 'Não suportado';
    }
}

// ==================== COPY API KEY ====================
document.getElementById('copy-apikey').addEventListener('click', () => {
    if (currentUser && currentUser.apiKey) {
        navigator.clipboard.writeText(currentUser.apiKey).then(() => {
            showToast('API Key copiada!');
        }).catch(() => {
            showToast('Erro ao copiar');
        });
    }
});

document.getElementById('btn-copy-key').addEventListener('click', () => {
    if (currentUser && currentUser.apiKey) {
        navigator.clipboard.writeText(currentUser.apiKey).then(() => {
            showToast('API Key copiada!');
        }).catch(() => {
            showToast('Erro ao copiar');
        });
    }
});

// ==================== LOGOUT ====================
document.getElementById('btn-logout').addEventListener('click', () => {
    send({ type: 'logout', token });
});

// ==================== UTILITÁRIOS ====================
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(msg, type = 'info') {
    const toast = document.getElementById('toast');
    const toastMsg = document.getElementById('toast-msg');
    toastMsg.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => { toast.classList.remove('show'); }, 3000);
}

function animateCounters() {
    document.querySelectorAll('.h-stat-num').forEach(el => {
        const target = parseInt(el.dataset.count);
        const duration = 1500;
        const start = performance.now();
        function update(now) {
            const elapsed = now - start;
            const progress = Math.min(elapsed / duration, 1);
            const ease = 1 - Math.pow(1 - progress, 3);
            el.textContent = Math.floor(ease * target);
            if (progress < 1) requestAnimationFrame(update);
        }
        requestAnimationFrame(update);
    });
}

// ==================== INICIALIZAÇÃO ====================
setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
        send({ type: 'ping' });
    }
}, 30000);

connectWebSocket();

if (token) {
    const checkInterval = setInterval(() => {
        if (ws && ws.readyState === WebSocket.OPEN) {
            send({ type: 'auth_check', token });
            clearInterval(checkInterval);
        }
    }, 500);
} else {
    showLogin();
}

// Previne zoom e gestos
document.addEventListener('gesturestart', e => e.preventDefault());
document.addEventListener('gesturechange', e => e.preventDefault());
document.addEventListener('gestureend', e => e.preventDefault());

// Previne scroll bounce no iOS
document.body.style.overscrollBehavior = 'none';

console.log('[VALLEY] App v2.0 inicializado. HID:', DEVICE_INFO.hid.substring(0, 16));
