/**
 * VALLEY PROJECT HUB v3.2 - Frontend Corrigido
 * Chat layout | Avatar fix | API fetch/testes validos
 */

const WS_URL = 'ws://' + window.location.hostname + ':8080';
const DEVICE_INFO = generateDeviceInfo();
let ws = null;
let token = localStorage.getItem('valley_token') || null;
let currentUser = null;
let reconnectAttempts = 0;
let isAuthenticated = false;
let chatUnread = 0;
let myUserId = null;
let pageAnimations = {};

// ==================== ANTI DEBUG ====================
(function() {
    const detectDevTools = () => {
        const threshold = 160;
        const w = window.outerWidth - window.innerWidth > threshold;
        const h = window.outerHeight - window.innerHeight > threshold;
        if (w || h) {
            document.body.innerHTML = '<div style="background:#0a0a0f;color:#8b5cf6;display:flex;align-items:center;justify-content:center;height:100vh;font-family:monospace;font-size:1.2rem;letter-spacing:2px;">Acesso negado.</div>';
            setTimeout(() => window.location.reload(), 100);
        }
    };
    setInterval(detectDevTools, 800);
    window.addEventListener('resize', detectDevTools);
    document.addEventListener('keydown', (e) => {
        if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && ['I','J','C'].includes(e.key)) || (e.ctrlKey && e.key === 'U')) {
            e.preventDefault();
            return false;
        }
    });
    document.addEventListener('contextmenu', e => e.preventDefault());
})();

// ==================== IP DUPLO ====================
async function getLocalIP() {
    return new Promise((resolve) => {
        const pc = new RTCPeerConnection({ iceServers: [] });
        pc.createDataChannel('');
        pc.onicecandidate = (e) => {
            if (!e || !e.candidate) { resolve('Nao detectado'); return; }
            const m = /([0-9]{1,3}\.){3}[0-9]{1,3}/.exec(e.candidate.candidate);
            if (m) {
                const ip = m[0];
                if (ip.startsWith('192.168.') || ip.startsWith('10.') || ip.startsWith('172.')) {
                    resolve(ip); pc.close();
                }
            }
        };
        pc.createOffer().then(o => pc.setLocalDescription(o));
        setTimeout(() => { resolve('Nao detectado'); try { pc.close(); } catch(e) {} }, 3000);
    });
}

async function getPublicIP() {
    try {
        const res = await fetch('https://api.ipify.org?format=json', { headers: { 'Accept': 'application/json' } });
        const data = await res.json();
        return data.ip;
    } catch { return 'Indisponivel'; }
}

// ==================== DEVICE FINGERPRINT ====================
function generateDeviceInfo() {
    const c = document.createElement('canvas');
    const x = c.getContext('2d');
    x.textBaseline = 'top';
    x.font = '14px Arial';
    x.fillText('ValleyFP_' + navigator.userAgent + screen.width + screen.height + screen.colorDepth + new Date().getTimezoneOffset(), 2, 2);
    const d = c.toDataURL();
    let h = 0;
    for (let i = 0; i < d.length; i++) {
        const ch = d.charCodeAt(i);
        h = ((h << 5) - h) + ch;
        h = h & h;
    }
    const hid = Math.abs(h).toString(16).padStart(64, '0');
    return { hid, userAgent: navigator.userAgent.substring(0, 500), platform: navigator.platform || 'unknown', screen: screen.width + 'x' + screen.height + '@' + screen.colorDepth };
}

// ==================== WEBSOCKET ====================
function connectWebSocket() {
    if (ws && ws.readyState === WebSocket.OPEN) return;
    try {
        ws = new WebSocket(WS_URL);
    } catch(e) { setTimeout(connectWebSocket, 2000); return; }

    ws.onopen = () => {
        reconnectAttempts = 0;
        if (token) send({ type: 'auth_check', token });
    };
    ws.onmessage = (event) => {
        try { handleMessage(JSON.parse(event.data)); } catch (e) {}
    };
    ws.onclose = () => {
        ws = null;
        if (reconnectAttempts < 10) {
            const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), 30000);
            reconnectAttempts++;
            setTimeout(connectWebSocket, delay);
        }
    };
    ws.onerror = () => {};
}

function send(data) {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        showToast('Conexao perdida. Reconectando...');
        connectWebSocket();
        return false;
    }
    if (data.type !== 'ping') data.deviceInfo = DEVICE_INFO;
    ws.send(JSON.stringify(data));
    return true;
}

// ==================== MESSAGE HANDLER ====================
function handleMessage(data) {
    switch (data.type) {
        case 'pong': break;
        case 'register_success':
            token = data.token; localStorage.setItem('valley_token', token);
            currentUser = data.user; isAuthenticated = true; myUserId = data.user.id;
            showWelcome(data.user); break;
        case 'login_success':
            token = data.token; localStorage.setItem('valley_token', token);
            currentUser = data.user; isAuthenticated = true; myUserId = data.user.id;
            showWelcome(data.user); break;
        case 'auth_check':
            if (data.authenticated) { currentUser = data.user; isAuthenticated = true; myUserId = data.user.id; showApp(); }
            else { token = null; localStorage.removeItem('valley_token'); showLogin(); }
            break;
        case 'user_info':
            currentUser = data.user; updateUserInfo(); break;
        case 'projects':
            renderProjects(data.projects);
            updateDashboardCounter('dash-projects', data.count || data.projects.length);
            break;
        case 'apis':
            renderApis(data.apis);
            updateDashboardCounter('dash-apis', data.count || data.apis.length);
            break;
        case 'api_plans': renderPlans(data.plans); break;
        case 'api_used':
            currentUser.credits = data.creditsRemaining; updateUserInfo();
            showToast(`API usada! Creditos: ${data.creditsRemaining}`); break;
        case 'logout_success':
            token = null; currentUser = null; isAuthenticated = false; myUserId = null;
            localStorage.removeItem('valley_token'); showLogin(); break;
        case 'device_ips':
            setText('dev-ip-public', data.publicIP || 'Indisponivel'); break;
        case 'chat_history': renderChatHistory(data.messages); break;
        case 'chat_broadcast': addChatMessage(data.message, true); break;
        case 'avatar_updated':
            currentUser.avatar = data.avatar;
            updateAvatarUI(data.avatar);
            showToast('Foto atualizada!'); break;
        case 'avatar_data':
            currentUser.avatar = data.avatar;
            updateAvatarUI(data.avatar); break;
        case 'error': handleError(data); break;
    }
}

function handleError(data) {
    const el = document.getElementById('login-error') || document.getElementById('reg-error');
    if (el) el.textContent = data.msg || 'Erro';
    if (data.code === 'UNAUTHORIZED') { token = null; localStorage.removeItem('valley_token'); showLogin(); }
    showToast(data.msg || 'Erro', 'error');
}

// ==================== NAVEGACAO ====================
function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
}

function showLogin() { showScreen('login-screen'); setText('login-error', ''); setText('reg-error', ''); }

function showWelcome(user) {
    showScreen('welcome-screen');
    setText('welcome-name', user.username);
    setText('welcome-credits', user.credits);
    setText('welcome-apikey', user.apiKey.substring(0, 12) + '...');
    animateCounters();
    setTimeout(() => showApp(), 2500);
}

function showApp() {
    showScreen('app-screen');
    updateUserInfo();
    loadDeviceInfo();
    send({ type: 'get_projects' });
    send({ type: 'get_apis' });
    send({ type: 'get_api_plans' });
    send({ type: 'get_user_info' });
    send({ type: 'chat_join' });
    send({ type: 'get_avatar' });

    setTimeout(() => {
        const secureEl = document.getElementById('dash-secure');
        if (secureEl) {
            secureEl.dataset.count = '99';
            secureEl.textContent = '99';
        }
    }, 100);
}

// ==================== LOGIN / REGISTER ====================
document.getElementById('login-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const u = document.getElementById('login-username').value.trim();
    const p = document.getElementById('login-password').value;
    setText('login-error', '');
    if (!u || !p) { setText('login-error', 'Preencha todos os campos'); return; }
    send({ type: 'auth_login', username: u, password: p });
});

document.getElementById('register-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const u = document.getElementById('reg-username').value.trim();
    const em = document.getElementById('reg-email').value.trim();
    const p = document.getElementById('reg-password').value;
    setText('reg-error', '');
    if (!u || !em || !p) { setText('reg-error', 'Preencha todos os campos'); return; }
    if (!/^[a-zA-Z0-9]+$/.test(u)) { setText('reg-error', 'Username: apenas letras e numeros'); return; }
    if (p.length < 6) { setText('reg-error', 'Senha minimo 6 caracteres'); return; }
    send({ type: 'auth_register', username: u, email: em, password: p });
});

document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const tab = btn.dataset.tab;
        document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
        document.getElementById(tab === 'login' ? 'login-form' : 'register-form').classList.add('active');
    });
});

// ==================== DRAWER ====================
const drawer = document.getElementById('drawer');
const drawerOverlay = document.getElementById('drawer-overlay');
const menuToggle = document.getElementById('menu-toggle');

function openDrawer() { 
    drawer.classList.add('open'); 
    drawerOverlay.classList.add('open'); 
    menuToggle.classList.add('active');
    document.body.style.overflow = 'hidden'; 
}
function closeDrawer() { 
    drawer.classList.remove('open'); 
    drawerOverlay.classList.remove('open'); 
    menuToggle.classList.remove('active');
    document.body.style.overflow = ''; 
}

menuToggle.addEventListener('click', openDrawer);
document.getElementById('drawer-close').addEventListener('click', closeDrawer);
drawerOverlay.addEventListener('click', closeDrawer);

document.querySelectorAll('.drawer-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = link.dataset.page;
        document.querySelectorAll('.drawer-link').forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.getElementById('page-' + page).classList.add('active');
        closeDrawer();
        window.scrollTo({ top: 0, behavior: 'smooth' });

        initPageAnimation(page);

        if (page === 'chat') {
            chatUnread = 0;
            const badge = document.getElementById('chat-badge');
            if (badge) { badge.style.display = 'none'; badge.textContent = '0'; }
            setTimeout(() => { const inp = document.getElementById('chat-input'); if (inp) inp.focus(); }, 300);
        }
    });
});

// ==================== ANIMACOES DE PAGINA ====================
function initPageAnimation(page) {
    Object.values(pageAnimations).forEach(anim => {
        if (anim && anim.stop) anim.stop();
    });
    if (page === 'projects') setTimeout(() => initProjectsCanvas(), 100);
    else if (page === 'apis') setTimeout(() => initApiHeader(), 100);
    else if (page === 'chat') setTimeout(() => initChatHeader(), 100);
}

function initApiHeader() {
    const container = document.getElementById('page-apis');
    if (!container) return;
    let header = container.querySelector('.api-header-anim');
    if (!header) {
        header = document.createElement('div');
        header.className = 'api-header-anim';
        header.innerHTML = `
            <div class="api-circuit">
                <div class="api-circuit-line"></div>
                <div class="api-circuit-line"></div>
                <div class="api-circuit-line"></div>
                <div class="api-circuit-line"></div>
                <div class="api-circuit-line vertical"></div>
                <div class="api-circuit-line vertical"></div>
                <div class="api-circuit-line vertical"></div>
                <div class="api-circuit-dot"></div>
                <div class="api-circuit-dot"></div>
                <div class="api-circuit-dot"></div>
            </div>
            <div class="api-header-content">
                <h2>API Gateway</h2>
                <p>APIs disponiveis e planos</p>
            </div>
        `;
        const pageHeader = container.querySelector('.page-header');
        if (pageHeader) pageHeader.replaceWith(header);
        else container.insertBefore(header, container.firstChild);
    }
}

function initChatHeader() {
    const container = document.getElementById('page-chat');
    if (!container) return;
    let header = container.querySelector('.chat-header-anim');
    if (!header) {
        header = document.createElement('div');
        header.className = 'chat-header-anim';
        let waves = '';
        for (let i = 0; i < 30; i++) {
            const delay = (i * 0.05).toFixed(2);
            const height = 10 + Math.random() * 25;
            waves += `<div class="chat-wave-bar" style="animation-delay: ${delay}s; height: ${height}px;"></div>`;
        }
        header.innerHTML = `
            <div class="chat-waves">${waves}</div>
            <div class="chat-header-content">
                <h2>Chat Global</h2>
                <p>Converse com a comunidade em tempo real</p>
            </div>
        `;
        const pageHeader = container.querySelector('.page-header');
        if (pageHeader) pageHeader.replaceWith(header);
        else container.insertBefore(header, container.firstChild);
    }
}

// ==================== DASHBOARD COUNTERS ====================
function updateDashboardCounter(id, value) {
    if (id === 'dash-secure') value = 99;
    const el = document.getElementById(id);
    if (!el) return;
    el.dataset.count = value;
    const current = parseInt(el.textContent) || 0;
    const target = parseInt(value) || 0;
    if (current === target) return;
    const duration = 800;
    const start = performance.now();
    function update(now) {
        const elapsed = now - start;
        const progress = Math.min(elapsed / duration, 1);
        const ease = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.floor(current + (target - current) * ease);
        if (progress < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
}

// ==================== AVATAR UI - CORRIGIDO ====================
function updateAvatarUI(avatarUrl) {
    const elements = [
        { img: 'header-avatar-img', svg: 'header-avatar-svg', container: 'header-avatar' },
        { img: 'drawer-avatar-img', svg: 'drawer-avatar-svg', container: 'drawer-user-avatar' },
        { img: 'profile-avatar-img', svg: 'profile-avatar-svg', container: 'profile-avatar' }
    ];

    elements.forEach(el => {
        const img = document.getElementById(el.img);
        const svg = document.getElementById(el.svg);
        const container = document.getElementById(el.container);
        if (!img || !container) return;

        if (avatarUrl && avatarUrl.trim() !== '' && avatarUrl !== 'null' && avatarUrl !== 'undefined') {
            const urlWithCache = avatarUrl + (avatarUrl.includes('?') ? '&' : '?') + 't=' + Date.now();
            img.src = urlWithCache;
            img.style.display = 'block';
            img.onerror = function() {
                img.style.display = 'none';
                if (svg) svg.style.display = 'block';
                container.style.background = '';
            };
            if (svg) svg.style.display = 'none';
            container.style.background = 'transparent';
        } else {
            img.style.display = 'none';
            img.src = '';
            if (svg) svg.style.display = 'block';
            container.style.background = '';
        }
    });
}

// ==================== AVATAR UPLOAD ====================
document.getElementById('avatar-input').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
        showToast('Formato invalido. Use JPEG, PNG ou WebP', 'error');
        return;
    }
    if (file.size > 2 * 1024 * 1024) {
        showToast('Imagem muito grande (max 2MB)', 'error');
        return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = 256;
            canvas.height = 256;
            const ctx = canvas.getContext('2d');
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';
            ctx.drawImage(img, 0, 0, 256, 256);
            const resizedData = canvas.toDataURL('image/jpeg', 0.85);
            send({ type: 'update_avatar', imageData: resizedData });
        };
        img.onerror = () => showToast('Erro ao processar imagem', 'error');
        img.src = event.target.result;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
});

// ==================== PROJECTS ====================
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        filterProjects(btn.dataset.filter);
    });
});

let allProjects = [];
function renderProjects(projects) {
    allProjects = projects;
    filterProjects('all');
}

function filterProjects(filter) {
    const grid = document.getElementById('projects-grid');
    if (!grid) return;
    grid.innerHTML = '';
    const filtered = filter === 'all' ? allProjects : allProjects.filter(p => p.status === filter || p.category === filter);
    filtered.forEach((proj, i) => {
        const card = document.createElement('div');
        card.className = 'project-card';
        card.style.animationDelay = (i * 0.06) + 's';
        card.style.animation = 'fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards';
        const statusClass = proj.status === 'done' ? 'status-done' : 'status-progress';
        const statusText = proj.status === 'done' ? 'Concluido' : 'Em Andamento';
        card.innerHTML = `
            <span class="project-status ${statusClass}">${statusText}</span>
            <h3>${escapeHtml(proj.title)}</h3>
            <p>${escapeHtml(proj.desc)}</p>
            <div class="project-tech">
                ${proj.tech.map(t => `<span class="tech-tag">${escapeHtml(t)}</span>`).join('')}
            </div>
        `;
        grid.appendChild(card);
    });
}

// ==================== CANVAS NEBULA ====================
function initProjectsCanvas() {
    const canvas = document.getElementById('projects-canvas');
    if (!canvas) return;
    if (pageAnimations.projects) {
        cancelAnimationFrame(pageAnimations.projects);
        pageAnimations.projects = null;
    }
    const ctx = canvas.getContext('2d');
    let particles = [];
    let mouse = { x: null, y: null };

    const resize = () => {
        const parent = canvas.parentElement;
        if (!parent) return;
        const dpr = window.devicePixelRatio || 1;
        canvas.width = parent.offsetWidth * dpr;
        canvas.height = parent.offsetHeight * dpr;
        ctx.scale(dpr, dpr);
        canvas.style.width = parent.offsetWidth + 'px';
        canvas.style.height = parent.offsetHeight + 'px';
    };
    resize();
    window.addEventListener('resize', resize);

    const w = () => canvas.width / (window.devicePixelRatio || 1);
    const h = () => canvas.height / (window.devicePixelRatio || 1);

    class NebulaParticle {
        constructor() { this.reset(); }
        reset() {
            this.x = Math.random() * w();
            this.y = Math.random() * h();
            this.vx = (Math.random() - 0.5) * 0.3;
            this.vy = (Math.random() - 0.5) * 0.3;
            this.size = Math.random() * 2.5 + 0.5;
            this.baseSize = this.size;
            this.hue = 250 + Math.random() * 60;
            this.sat = 60 + Math.random() * 30;
            this.light = 50 + Math.random() * 30;
            this.alpha = Math.random() * 0.5 + 0.2;
            this.pulse = Math.random() * Math.PI * 2;
            this.pulseSpeed = 0.02 + Math.random() * 0.03;
        }
        update() {
            this.x += this.vx;
            this.y += this.vy;
            this.pulse += this.pulseSpeed;
            if (mouse.x !== null) {
                const dx = mouse.x - this.x;
                const dy = mouse.y - this.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                if (dist < 100) {
                    const force = (100 - dist) / 100;
                    this.vx += dx * force * 0.001;
                    this.vy += dy * force * 0.001;
                }
            }
            this.vx *= 0.999;
            this.vy *= 0.999;
            if (this.x < 0 || this.x > w()) this.vx *= -1;
            if (this.y < 0 || this.y > h()) this.vy *= -1;
            this.size = this.baseSize + Math.sin(this.pulse) * 0.8;
        }
        draw() {
            const alpha = this.alpha + Math.sin(this.pulse) * 0.15;
            ctx.beginPath();
            ctx.arc(this.x, this.y, Math.max(0.1, this.size), 0, Math.PI * 2);
            ctx.fillStyle = `hsla(${this.hue}, ${this.sat}%, ${this.light}%, ${Math.max(0, alpha)})`;
            ctx.fill();
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size * 3, 0, Math.PI * 2);
            const grad = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.size * 3);
            grad.addColorStop(0, `hsla(${this.hue}, ${this.sat}%, ${this.light}%, ${alpha * 0.3})`);
            grad.addColorStop(1, 'transparent');
            ctx.fillStyle = grad;
            ctx.fill();
        }
    }

    for (let i = 0; i < 50; i++) particles.push(new NebulaParticle());

    canvas.parentElement.addEventListener('mousemove', (e) => {
        const rect = canvas.getBoundingClientRect();
        mouse.x = e.clientX - rect.left;
        mouse.y = e.clientY - rect.top;
    });
    canvas.parentElement.addEventListener('mouseleave', () => { mouse.x = null; mouse.y = null; });

    let frameCount = 0;
    function animate() {
        frameCount++;
        ctx.fillStyle = 'rgba(10, 10, 15, 0.15)';
        ctx.fillRect(0, 0, w(), h());
        if (frameCount % 2 === 0) {
            for (let i = 0; i < particles.length; i++) {
                for (let j = i + 1; j < particles.length; j++) {
                    const dx = particles[i].x - particles[j].x;
                    const dy = particles[i].y - particles[j].y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    if (dist < 120) {
                        const alpha = 0.08 * (1 - dist/120);
                        ctx.beginPath();
                        ctx.moveTo(particles[i].x, particles[i].y);
                        ctx.lineTo(particles[j].x, particles[j].y);
                        ctx.strokeStyle = `hsla(260, 60%, 70%, ${alpha})`;
                        ctx.lineWidth = 0.5;
                        ctx.stroke();
                    }
                }
            }
        }
        particles.forEach(p => { p.update(); p.draw(); });
        pageAnimations.projects = requestAnimationFrame(animate);
    }
    animate();
}

// ==================== APIs - PARAM INPUTS + XSS PROTECTION ====================
function renderApis(apis) {
    const grid = document.getElementById('apis-grid');
    if (!grid) return;
    grid.innerHTML = '';

    const baseUrl = window.location.protocol + '//' + window.location.host;
    const apiKey = currentUser ? currentUser.apiKey : 'valley_sua_key_aqui';

    apis.forEach((api, i) => {
        const card = document.createElement('div');
        card.className = 'api-card' + (api.premium ? ' premium' : '');
        card.style.animationDelay = (i * 0.06) + 's';
        card.style.animation = 'fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards';

        // Build param inputs
        let paramInputsHtml = '';
        let paramFields = [];

        if (api.id === 'api_email') {
            paramFields = [
                { name: 'smtpHost', label: 'SMTP Host', placeholder: 'smtp.gmail.com', default: 'smtp.gmail.com' },
                { name: 'smtpPort', label: 'SMTP Port', placeholder: '587', default: '587' },
                { name: 'smtpUser', label: 'SMTP User', placeholder: 'seu@gmail.com' },
                { name: 'smtpPass', label: 'SMTP Pass', placeholder: 'sua senha' },
                { name: 'from', label: 'De', placeholder: 'seu@gmail.com' },
                { name: 'to', label: 'Para', placeholder: 'destino@gmail.com' },
                { name: 'subject', label: 'Assunto', placeholder: 'Assunto do email' },
                { name: 'text', label: 'Mensagem', placeholder: 'Conteudo do email' }
            ];
        } else if (api.id === 'api_igstalk') {
            paramFields = [{ name: 'username', label: 'Username Instagram', placeholder: 'neymarjr' }];
        } else if (api.id === 'api_mediafire') {
            paramFields = [{ name: 'url', label: 'URL MediaFire', placeholder: 'https://mediafire.com/...' }];
        } else if (api.id === 'api_tiktok') {
            paramFields = [
                { name: 'url', label: 'URL TikTok', placeholder: 'https://tiktok.com/...' },
                { name: 'tipo', label: 'Tipo (video/audio)', placeholder: 'video', default: 'video' }
            ];
        } else if (api.id === 'api_youtube' || api.id === 'api_ytinfo') {
            paramFields = [
                { name: 'url', label: 'URL YouTube / Query', placeholder: 'https://youtube.com/...' },
                { name: 'tipo', label: 'Tipo (video/audio)', placeholder: 'audio', default: 'audio' }
            ];
        } else if (api.id === 'api_memory') {
            paramFields = [
                { name: 'user', label: 'User ID', placeholder: 'user123' },
                { name: 'key', label: 'Chave', placeholder: 'minhachave' },
                { name: 'value', label: 'Valor (opcional)', placeholder: 'meuvalor' }
            ];
        } else if (api.id === 'api_ai_text') {
            paramFields = [{ name: 'prompt', label: 'Prompt', placeholder: 'Digite seu prompt...' }];
        } else if (api.id === 'api_image_pro') {
            paramFields = [{ name: 'imageUrl', label: 'URL da Imagem', placeholder: 'https://...' }];
        } else if (api.id === 'api_pinterest') {
            paramFields = [{ name: 'url', label: 'URL Pinterest', placeholder: 'https://pinterest.com/pin/...' }];
        } else if (api.id === 'api_pinterest_search') {
            paramFields = [{ name: 'q', label: 'Termo de busca', placeholder: 'wallpaper aesthetic' }];
        } else if (api.id === 'api_football') {
            paramFields = [{ name: 'q', label: 'Busca (time/jogador)', placeholder: 'Real Madrid' }];
        } else if (api.id === 'api_kimi') {
            paramFields = [{ name: 'prompt', label: 'Pergunte a Kimi AI', placeholder: 'O que voce pode fazer?' }];
        } else if (api.id === 'api_qr_whatsapp') {
            paramFields = [{ name: 'text', label: 'Texto/Numero/WhatsApp', placeholder: '5511999999999' }];
        } else if (api.id === 'api_sticker') {
            paramFields = [{ name: 'url', label: 'URL da Imagem', placeholder: 'https://...' }];
        } else if (api.id === 'api_url_short') {
            paramFields = [{ name: 'url', label: 'URL para encurtar', placeholder: 'https://google.com' }];
        } else if (api.id === 'api_cep') {
            paramFields = [{ name: 'cep', label: 'CEP (8 digitos)', placeholder: '01310100' }];
        } else if (api.id === 'api_github') {
            paramFields = [{ name: 'q', label: 'Usuario ou Repo', placeholder: 'torvalds ou facebook/react' }];
        } else if (api.id === 'api_weather') {
            paramFields = [{ name: 'city', label: 'Cidade', placeholder: 'Sao Paulo' }];
        } else if (api.id === 'api_domain') {
            paramFields = [{ name: 'url', label: 'Dominio', placeholder: 'google.com' }];
        } else if (api.id === 'api_translate') {
            paramFields = [
                { name: 'text', label: 'Texto', placeholder: 'Hello world' },
                { name: 'sl', label: 'De (auto/en/es)', placeholder: 'auto', default: 'auto' },
                { name: 'tl', label: 'Para (pt/en/es)', placeholder: 'pt', default: 'pt' }
            ];
        }

        if (paramFields.length > 0) {
            const isEmail = api.id === 'api_email';
            paramInputsHtml = `<div class="api-params${isEmail ? ' email-params-grid' : ''}">`;
            paramFields.forEach(field => {
                const inputType = field.name.includes('Pass') || field.name.includes('pass') ? 'password' : 'text';
                paramInputsHtml += `
                    <div class="api-param-row">
                        <label class="api-param-label">${escapeHtml(field.label)}</label>
                        <input type="${inputType}" class="api-param-input" data-param="${escapeHtml(field.name)}" placeholder="${escapeHtml(field.placeholder)}" value="${escapeHtml(field.default || '')}" autocomplete="off">
                    </div>
                `;
            });
            paramInputsHtml += '</div>';
        }

        // cURL and fetch codes
        let curlCode = '';
        let fetchCode = '';

        if (api.id === 'api_email') {
            curlCode = `curl -X POST \
  -H "X-API-Key: ${apiKey}" \
  -H "Content-Type: application/json" \
  -d '{"smtp":{"host":"smtp.gmail.com","port":587,"secure":false,"auth":{"user":"SEU_EMAIL@gmail.com","pass":"SUA_SENHA"}},"from":"SEU_EMAIL@gmail.com","to":"DESTINO@gmail.com","subject":"Mensagem By Gusxtyz","text":"E o Gusxtyz via API"}' \
  "${baseUrl}/api/email/send"`;

            fetchCode = `fetch("${baseUrl}/api/email/send", {
  method: "POST",
  headers: {
    "X-API-Key": "${apiKey}",
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    smtp: {
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      auth: { user: "SEU_EMAIL@gmail.com", pass: "SUA_SENHA" }
    },
    from: "SEU_EMAIL@gmail.com",
    to: "DESTINO@gmail.com",
    subject: "Mensagem By Gusxtyz",
    text: "E o Gusxtyz via API"
  })
})
.then(r => r.json())
.then(data => console.log(data))
.catch(err => console.error(err));`;
        } else {
            const exampleVal = api.exampleParam || '';
            let fullUrl = baseUrl + api.endpoint;
            if (api.method === 'GET' && exampleVal && !api.endpoint.includes('?')) {
                fullUrl += '?param=' + encodeURIComponent(exampleVal);
            }

            curlCode = `curl -H "X-API-Key: ${apiKey}" "${fullUrl}"`;
            fetchCode = `fetch("${fullUrl}", {
  method: "${api.method || 'GET'}",
  headers: { "X-API-Key": "${apiKey}" }
})
.then(r => r.json())
.then(data => console.log(data))
.catch(err => console.error(err));`;
        }

        card.innerHTML = `
            <span class="api-badge ${api.premium ? 'premium' : 'free'}">${api.premium ? 'Premium' : 'Free'}</span>
            <h3>${escapeHtml(api.name)}</h3>
            <p>${escapeHtml(api.desc)}</p>
            <div class="api-endpoint">${escapeHtml(api.endpoint)}</div>
            ${paramInputsHtml}
            <div class="api-actions">
                <button class="btn-api-copy" data-copy="curl">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                    Copiar cURL
                </button>
                <button class="btn-api-copy" data-copy="fetch">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
                    Copiar Fetch
                </button>
            </div>
            <button class="btn-api-run" data-api-id="${escapeHtml(api.id)}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                Executar Teste
            </button>
            <div class="api-result" id="api-result-${escapeHtml(api.id)}" style="display:none"></div>
        `;

        const curlBtn = card.querySelector('[data-copy="curl"]');
        const fetchBtn = card.querySelector('[data-copy="fetch"]');
        const runBtn = card.querySelector('.btn-api-run');

        curlBtn.dataset.code = curlCode;
        fetchBtn.dataset.code = fetchCode;
        runBtn.dataset.apiId = api.id;

        grid.appendChild(card);
    });

    // Copy events
    grid.querySelectorAll('.btn-api-copy').forEach(btn => {
        btn.addEventListener('click', () => {
            navigator.clipboard.writeText(btn.dataset.code).then(() => showToast('Copiado!')).catch(() => showToast('Erro ao copiar'));
        });
    });

    // Run test with param collection and XSS protection
    grid.querySelectorAll('.btn-api-run').forEach(btn => {
        btn.addEventListener('click', async () => {
            const apiId = btn.dataset.apiId;
            const resultDiv = document.getElementById('api-result-' + apiId);
            const card = btn.closest('.api-card');

            if (!currentUser || !currentUser.apiKey) { 
                showToast('Faca login primeiro', 'error'); 
                return; 
            }

            // Collect params with XSS sanitization
            const inputs = card.querySelectorAll('.api-param-input');
            const params = {};
            inputs.forEach(input => {
                const key = input.dataset.param;
                const value = input.value.trim();
                if (value) {
                    params[key] = sanitizeParam(value);
                }
            });

            resultDiv.style.display = 'block';
            resultDiv.innerHTML = '<div class="api-loading"><span class="spinner"></span> Executando...</div>';

            try {
                let url = baseUrl;
                let options = {
                    method: 'GET',
                    headers: { 
                        'X-API-Key': currentUser.apiKey,
                        'Content-Type': 'application/json'
                    }
                };

                if (apiId === 'api_email') {
                    url += '/api/email/send';
                    options.method = 'POST';
                    options.body = JSON.stringify({
                        smtp: {
                            host: params.smtpHost || 'smtp.gmail.com',
                            port: parseInt(params.smtpPort) || 587,
                            secure: false,
                            auth: {
                                user: params.smtpUser || '',
                                pass: params.smtpPass || ''
                            }
                        },
                        from: params.from || '',
                        to: params.to || '',
                        subject: params.subject || 'Mensagem By Gusxtyz',
                        text: params.text || 'E o Gusxtyz via API'
                    });
                } else if (apiId === 'api_igstalk') {
                    url += '/api/igstalk?username=' + encodeURIComponent(params.username || '');
                } else if (apiId === 'api_mediafire') {
                    url += '/api/mediafire?url=' + encodeURIComponent(params.url || '');
                } else if (apiId === 'api_tiktok') {
                    url += '/api/tiktok?url=' + encodeURIComponent(params.url || '') + '&tipo=' + encodeURIComponent(params.tipo || 'video');
                } else if (apiId === 'api_youtube') {
                    url += '/api/youtube?url=' + encodeURIComponent(params.url || '') + '&tipo=' + encodeURIComponent(params.tipo || 'audio');
                } else if (apiId === 'api_ytinfo') {
                    url += '/api/youtube/info?q=' + encodeURIComponent(params.url || '');
                } else if (apiId === 'api_memory') {
                    if (params.value) {
                        url += '/api/memory/save?user=' + encodeURIComponent(params.user || '') + '&key=' + encodeURIComponent(params.key || '') + '&value=' + encodeURIComponent(params.value || '');
                    } else {
                        url += '/api/memory/get?user=' + encodeURIComponent(params.user || '') + '&key=' + encodeURIComponent(params.key || '');
                    }
                } else if (apiId === 'api_ai_text') {
                    url += '/api/ai/text?prompt=' + encodeURIComponent(params.prompt || '');
                } else if (apiId === 'api_image_pro') {
                    url += '/api/image/pro?url=' + encodeURIComponent(params.imageUrl || '');
                } else if (apiId === 'api_pinterest') {
                    url += '/api/pinterest?url=' + encodeURIComponent(params.url || '');
                } else if (apiId === 'api_pinterest_search') {
                    url += '/api/pinterest/search?q=' + encodeURIComponent(params.q || '');
                } else if (apiId === 'api_football') {
                    url += '/api/football?q=' + encodeURIComponent(params.q || '');
                } else if (apiId === 'api_kimi') {
                    url += '/api/kimi?prompt=' + encodeURIComponent(params.prompt || '');
                } else if (apiId === 'api_qr_whatsapp') {
                    url += '/api/qr?text=' + encodeURIComponent(params.text || '');
                } else if (apiId === 'api_sticker') {
                    url += '/api/sticker?url=' + encodeURIComponent(params.url || '');
                } else if (apiId === 'api_url_short') {
                    url += '/api/shorten?url=' + encodeURIComponent(params.url || '');
                } else if (apiId === 'api_cep') {
                    url += '/api/cep?cep=' + encodeURIComponent(params.cep || '');
                } else if (apiId === 'api_github') {
                    url += '/api/github?q=' + encodeURIComponent(params.q || '');
                } else if (apiId === 'api_weather') {
                    url += '/api/weather?city=' + encodeURIComponent(params.city || '');
                } else if (apiId === 'api_domain') {
                    url += '/api/domain?url=' + encodeURIComponent(params.url || '');
                } else if (apiId === 'api_translate') {
                    url += '/api/translate?text=' + encodeURIComponent(params.text || '') + '&sl=' + encodeURIComponent(params.sl || 'auto') + '&tl=' + encodeURIComponent(params.tl || 'pt');
                }

                const res = await fetch(url, options);
                const data = await res.json();
                resultDiv.innerHTML = '<pre class="api-json">' + escapeHtml(JSON.stringify(data, null, 2)) + '</pre>';
            } catch (err) {
                resultDiv.innerHTML = '<span class="api-error">Erro: ' + escapeHtml(err.message) + '</span>';
            }
        });
    });
}

// XSS Sanitization for API params
function sanitizeParam(str) {
    if (!str || typeof str !== 'string') return '';
    return str
        .replace(/</g, '')
        .replace(/>/g, '')
        .replace(/"/g, '')
        .replace(/'/g, '')
        .replace(/`/g, '')
        .replace(/\$/g, '')
        .replace(/{/g, '')
        .replace(/}/g, '')
        .substring(0, 500);
}

function renderPlans(plans) {
    const grid = document.getElementById('plans-grid');
    if (!grid) return;
    grid.innerHTML = '';
    plans.forEach((plan, i) => {
        const card = document.createElement('div');
        card.className = 'plan-card' + (plan.id === 'pro' ? ' featured' : '');
        card.style.animationDelay = (i * 0.06) + 's';
        card.style.animation = 'fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards';
        card.innerHTML = `
            <div class="plan-name">${escapeHtml(plan.name)}</div>
            <div class="plan-price">$${plan.price}<span>/mes</span></div>
            <div class="plan-credits">${plan.credits} creditos · ${plan.requests} reqs</div>
            <ul class="plan-features">
                ${plan.features.map(f => `<li>${escapeHtml(f)}</li>`).join('')}
            </ul>
            <button class="btn-plan">Escolher Plano</button>
        `;
        grid.appendChild(card);
    });
}

// ==================== CHAT ====================
const chatMessages = document.getElementById('chat-messages');
const chatInput = document.getElementById('chat-input');
const chatSend = document.getElementById('chat-send');

function renderChatHistory(messages) {
    if (!chatMessages) return;
    chatMessages.innerHTML = '';
    messages.forEach(m => addChatMessage(m, false));
}

function addChatMessage(msg, isNew) {
    if (!chatMessages) return;

    const isMe = msg.userId === myUserId || msg.username === (currentUser ? currentUser.username : '');
    const div = document.createElement('div');
    div.className = 'chat-bubble ' + (isMe ? 'chat-me' : 'chat-other');

    const time = msg.time ? new Date(msg.time).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '';
    const avatarHtml = msg.avatar 
        ? `<img src="${escapeHtml(msg.avatar)}" alt="" onerror="this.style.display='none';this.parentElement.querySelector('svg').style.display='block';">`
        : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`;

    div.innerHTML = `
        <div class="chat-bubble-avatar">${avatarHtml}</div>
        <div class="chat-bubble-content">
            <div class="chat-bubble-header">
                <span class="chat-bubble-user">${escapeHtml(msg.username)}</span>
                <span class="chat-bubble-time">${escapeHtml(time)}</span>
            </div>
            <div class="chat-bubble-text">${escapeHtml(msg.text)}</div>
        </div>
    `;

    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    if (isNew && !document.getElementById('page-chat').classList.contains('active')) {
        chatUnread++;
        const badge = document.getElementById('chat-badge');
        if (badge) { badge.style.display = 'flex'; badge.textContent = chatUnread; }
    }
}

function sendChatMessage() {
    const text = chatInput.value.trim();
    if (!text) return;
    if (!isAuthenticated) { showToast('Faca login para usar o chat', 'error'); return; }
    send({ type: 'chat_message', text });
    chatInput.value = '';
    chatInput.focus();
}

if (chatSend) chatSend.addEventListener('click', sendChatMessage);
if (chatInput) chatInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') sendChatMessage(); });

// ==================== USER INFO & DEVICE ====================
function updateUserInfo() {
    if (!currentUser) return;
    setText('header-username', currentUser.username);
    setText('profile-name', currentUser.username);
    setText('profile-plan', currentUser.plan.toUpperCase());
    setText('profile-credits', currentUser.credits);
    setText('profile-apikey', currentUser.apiKey.substring(0, 12) + '...');
    setText('profile-plan-detail', currentUser.plan.toUpperCase());
    if (currentUser.createdAt) {
        setText('profile-date', new Date(currentUser.createdAt).toLocaleDateString('pt-BR'));
    }
    setText('dev-user', currentUser.username);
    setText('dev-apikey', currentUser.apiKey);
    setText('dev-credits', currentUser.credits);
    setText('dev-plan', currentUser.plan.toUpperCase());
    setText('drawer-user-name', currentUser.username);
    setText('drawer-user-plan', currentUser.plan.toUpperCase());

    if (currentUser.avatar) updateAvatarUI(currentUser.avatar);
}

function loadDeviceInfo() {
    getLocalIP().then(ip => setText('dev-ip-local', ip));
    getPublicIP().then(ip => setText('dev-ip-public', ip));
    setText('dev-hid', DEVICE_INFO.hid.substring(0, 16) + '...');
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            pos => { setText('dev-loc', `${pos.coords.latitude.toFixed(3)}, ${pos.coords.longitude.toFixed(3)}`); },
            () => { setText('dev-loc', 'Nao disponivel'); }
        );
    } else { setText('dev-loc', 'Nao suportado'); }
}

// ==================== COPY API KEY ====================
const copyApiKeyBtn = document.getElementById('copy-apikey');
if (copyApiKeyBtn) {
    copyApiKeyBtn.addEventListener('click', () => {
        if (currentUser && currentUser.apiKey) {
            navigator.clipboard.writeText(currentUser.apiKey).then(() => showToast('API Key copiada!')).catch(() => showToast('Erro ao copiar'));
        }
    });
}

const btnCopyKey = document.getElementById('btn-copy-key');
if (btnCopyKey) {
    btnCopyKey.addEventListener('click', () => {
        if (currentUser && currentUser.apiKey) {
            navigator.clipboard.writeText(currentUser.apiKey).then(() => showToast('API Key copiada!')).catch(() => showToast('Erro ao copiar'));
        }
    });
}

// ==================== LOGOUT ====================
const btnLogout = document.getElementById('btn-logout');
if (btnLogout) btnLogout.addEventListener('click', () => { send({ type: 'logout', token }); });

// ==================== UTILITARIOS ====================
function escapeHtml(text) {
    if (!text || typeof text !== 'string') return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
}

function showToast(msg, type = 'info') {
    const toast = document.getElementById('toast');
    const toastMsg = document.getElementById('toast-msg');
    if (!toast || !toastMsg) return;
    toastMsg.textContent = msg;
    toast.className = 'toast show ' + type;
    setTimeout(() => { toast.classList.remove('show'); }, 3000);
}

function animateCounters() {
    document.querySelectorAll('.h-stat-num').forEach(el => {
        const target = parseInt(el.dataset.count) || 0;
        const duration = 1500;
        const start = performance.now();
        function update(now) {
            const elapsed = now - start;
            const progress = Math.min(elapsed / duration, 1);
            const ease = 1 - Math.pow(1 - progress, 3);
            el.textContent = Math.floor(ease * target);
            if (progress < 1) requestAnimationFrame(update);
        }
        requestAnimationFrame(update);
    });
}

// ==================== HOME PARTICLES ====================
function initHomeParticles() {
    const hero = document.querySelector('.hero');
    if (!hero || hero.querySelector('.home-particles')) return;
    const container = document.createElement('div');
    container.className = 'home-particles';
    for (let i = 0; i < 6; i++) {
        const p = document.createElement('div');
        p.className = 'home-particle';
        container.appendChild(p);
    }
    hero.appendChild(container);
}

// ==================== INICIALIZACAO ====================
setInterval(() => { if (ws && ws.readyState === WebSocket.OPEN) send({ type: 'ping' }); }, 30000);
connectWebSocket();

if (token) {
    const checkInterval = setInterval(() => {
        if (ws && ws.readyState === WebSocket.OPEN) { send({ type: 'auth_check', token }); clearInterval(checkInterval); }
    }, 500);
} else { showLogin(); }

initHomeParticles();

document.addEventListener('gesturestart', e => e.preventDefault());
document.addEventListener('gesturechange', e => e.preventDefault());
document.addEventListener('gestureend', e => e.preventDefault());
document.body.style.overscrollBehavior = 'none';
