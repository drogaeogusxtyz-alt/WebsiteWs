/**
 * VALLEY PROJECT HUB v2.0
 * Servidor WebSocket + HTTP + APIs Funcionais
 * Roda no Termux (Node.js)
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');
require('dotenv').config();

// ==================== APIs FUNCIONAIS ====================
const { sendEmail } = require('./apis/email/send');
const { igStalk } = require('./apis/igstalk/stalk');
const { mediaFireDownload } = require('./apis/mediafire/download');
const { tiktokDownload } = require('./apis/tiktok/download');
const { youtubeInfo, youtubeDownload } = require('./apis/youtube/download');
const { memorySave, memoryGet } = require('./apis/memory/store');

// ==================== CONFIGURAÇÕES ====================
const PORT = process.env.PORT || 3000;
const WS_PORT = process.env.WS_PORT || 8080;
const JWT_SECRET = process.env.JWT_SECRET || 'valley_termux_secret_2026_change_me_now';
const MAX_REQ_PER_MIN = parseInt(process.env.MAX_REQUESTS_PER_MINUTE) || 30;
const MAX_REQ_PER_HOUR = parseInt(process.env.MAX_REQUESTS_PER_HOUR) || 500;
const BLOCK_DURATION = parseInt(process.env.BLOCK_DURATION_MS) || 86400000;
const DEFAULT_CREDITS = parseInt(process.env.DEFAULT_FREE_CREDITS) || 100;
const COST_PER_REQ = parseInt(process.env.COST_PER_REQUEST) || 10;

const DATA_DIR = path.join(__dirname, 'data');
const DB_USERS = path.join(DATA_DIR, 'users.json');
const DB_BLACKLIST = path.join(DATA_DIR, 'blacklist.json');
const DB_REQUESTS = path.join(DATA_DIR, 'requests.json');
const DB_SESSIONS = path.join(DATA_DIR, 'sessions.json');
const DB_PROJECTS = path.join(DATA_DIR, 'projects.json');
const DB_APIS = path.join(DATA_DIR, 'apis.json');
const DB_RATE_LIMIT = path.join(DATA_DIR, 'rate_limit.json');
const DOWNLOADS_DIR = path.join(DATA_DIR, 'downloads');

// Garante diretórios
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DOWNLOADS_DIR)) fs.mkdirSync(DOWNLOADS_DIR, { recursive: true });

// Inicializa DBs
const initDB = (file, defaultData) => {
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(defaultData, null, 2));
};
initDB(DB_USERS, []);
initDB(DB_BLACKLIST, { ips: {}, hids: {} });
initDB(DB_REQUESTS, []);
initDB(DB_SESSIONS, []);
initDB(DB_RATE_LIMIT, {});
initDB(DB_PROJECTS, [
    { id: 'proj_001', title: 'API Valley Core', status: 'done', category: 'api', desc: 'Core API system com WebSocket', tech: ['Node.js', 'WebSocket'] },
    { id: 'proj_002', title: 'Dashboard Analytics', status: 'progress', category: 'web', desc: 'Real-time analytics dashboard', tech: ['React', 'D3.js'] },
    { id: 'proj_003', title: 'Mobile Bridge', status: 'progress', category: 'mobile', desc: 'Mobile integration layer', tech: ['Flutter', 'Dart'] },
    { id: 'proj_004', title: 'AI Classifier', status: 'done', category: 'ai', desc: 'Image classification API', tech: ['Python', 'TensorFlow'] },
    { id: 'proj_005', title: 'Email Sender API', status: 'done', category: 'api', desc: 'API de envio de emails via SMTP', tech: ['Node.js', 'Nodemailer'] },
    { id: 'proj_006', title: 'Social Stalker', status: 'done', category: 'api', desc: 'Instagram profile stalker', tech: ['Node.js', 'Axios'] },
    { id: 'proj_007', title: 'Download Hub', status: 'done', category: 'api', desc: 'Download de YouTube, TikTok, MediaFire', tech: ['Node.js', 'yt-dlp'] }
]);
initDB(DB_APIS, [
    { id: 'api_email', name: 'Email Sender', endpoint: '/api/email/send', desc: 'Envia emails via SMTP customizado', premium: false, category: 'utility' },
    { id: 'api_igstalk', name: 'IG Stalker', endpoint: '/api/igstalk?username=', desc: 'Busca informações de perfil do Instagram', premium: false, category: 'social' },
    { id: 'api_mediafire', name: 'MediaFire DL', endpoint: '/api/mediafire?url=', desc: 'Download direto de arquivos do MediaFire', premium: false, category: 'download' },
    { id: 'api_tiktok', name: 'TikTok DL', endpoint: '/api/tiktok?url=', desc: 'Download de vídeos e áudios do TikTok', premium: false, category: 'download' },
    { id: 'api_youtube', name: 'YouTube DL', endpoint: '/api/youtube?url=', desc: 'Download de vídeos e áudios do YouTube', premium: false, category: 'download' },
    { id: 'api_ytinfo', name: 'YouTube Info', endpoint: '/api/youtube/info?q=', desc: 'Metadados de vídeos do YouTube', premium: false, category: 'utility' },
    { id: 'api_memory', name: 'Memory Store', endpoint: '/api/memory', desc: 'Armazenamento chave-valor por usuário', premium: false, category: 'utility' },
    { id: 'api_ai_text', name: 'AI Text Valley', endpoint: '/api/ai/text', desc: 'AI text generation (simulado)', premium: true, category: 'ai' },
    { id: 'api_image_pro', name: 'Image Valley Pro', endpoint: '/api/image/pro', desc: 'Advanced image processing', premium: true, category: 'ai' }
]);

// ==================== UTILITÁRIOS DE SEGURANÇA ====================
const locks = new Map();
const acquireLock = async (key, timeout = 5000) => {
    const start = Date.now();
    while (locks.has(key)) {
        if (Date.now() - start > timeout) return false;
        await new Promise(r => setTimeout(r, 10));
    }
    locks.set(key, true);
    return true;
};
const releaseLock = (key) => locks.delete(key);

const hash = (data) => crypto.createHash('sha256').update(String(data)).digest('hex');
const hmac = (data) => crypto.createHmac('sha256', JWT_SECRET).update(String(data)).digest('hex');

const genApiKey = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let key = 'valley_';
    for (let i = 0; i < 16; i++) key += chars.charAt(Math.floor(Math.random() * chars.length));
    return key;
};

const genToken = () => crypto.randomBytes(32).toString('hex');

const isValidText = (str, maxLen = 50) => {
    if (!str || typeof str !== 'string') return false;
    if (str.length > maxLen || str.length < 1) return false;
    return /^[a-zA-Z0-9]+$/.test(str);
};

const isValidEmail = (email) => {
    if (!email || typeof email !== 'string') return false;
    if (email.length > 100) return false;
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(email);
};

const isValidHID = (hid) => {
    if (!hid || typeof hid !== 'string') return false;
    if (hid.length !== 64) return false;
    return /^[a-f0-9]+$/.test(hid);
};

const readDB = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));
const writeDB = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
    fs.chmodSync(file, 0o600);
};

// ==================== BLACKLIST & RATE LIMIT ====================
const isBlacklisted = (ip, hid) => {
    const bl = readDB(DB_BLACKLIST);
    const now = Date.now();
    if (bl.ips[ip] && bl.ips[ip] > now) return true;
    if (bl.hids[hid] && bl.hids[hid] > now) return true;
    return false;
};

const blacklist = (ip, hid, permanent = true) => {
    const bl = readDB(DB_BLACKLIST);
    const expiry = permanent ? 9999999999999 : Date.now() + BLOCK_DURATION;
    if (ip) bl.ips[ip] = expiry;
    if (hid) bl.hids[hid] = expiry;
    writeDB(DB_BLACKLIST, bl);
};

const checkRateLimit = (ip, hid) => {
    const rl = readDB(DB_RATE_LIMIT);
    const now = Date.now();
    const key = hash(ip + (hid || 'unknown'));
    if (!rl[key]) rl[key] = { minute: [], hour: [], last: now };
    rl[key].minute = rl[key].minute.filter(t => now - t < 60000);
    rl[key].hour = rl[key].hour.filter(t => now - t < 3600000);
    if (rl[key].minute.length >= MAX_REQ_PER_MIN) return false;
    if (rl[key].hour.length >= MAX_REQ_PER_HOUR) return false;
    rl[key].minute.push(now);
    rl[key].hour.push(now);
    writeDB(DB_RATE_LIMIT, rl);
    return true;
};

// ==================== DDoS PROTECTION ====================
const connectionAttempts = new Map();
const ddosShield = (req, socket) => {
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress || 'unknown';
    const now = Date.now();
    if (!connectionAttempts.has(ip)) connectionAttempts.set(ip, []);
    const attempts = connectionAttempts.get(ip).filter(t => now - t < 10000);
    attempts.push(now);
    connectionAttempts.set(ip, attempts);
    if (attempts.length > 50) { blacklist(ip, null, true); socket.destroy(); return false; }
    if (attempts.length > 20) { socket.destroy(); return false; }
    return true;
};

// ==================== VALIDAÇÃO DE DEVICE ====================
const validateDeviceInfo = (deviceInfo) => {
    if (!deviceInfo || typeof deviceInfo !== 'object') return false;
    const required = ['hid', 'userAgent', 'platform', 'screen'];
    for (const field of required) if (!deviceInfo[field]) return false;
    if (!isValidHID(deviceInfo.hid)) return false;
    if (typeof deviceInfo.userAgent !== 'string' || deviceInfo.userAgent.length > 500) return false;
    if (typeof deviceInfo.platform !== 'string' || deviceInfo.platform.length > 50) return false;
    if (typeof deviceInfo.screen !== 'string' || deviceInfo.screen.length > 30) return false;
    return true;
};

// ==================== MIME TYPES & HEADERS ====================
const MIME_TYPES = {
    '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript',
    '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg',
    '.gif': 'image/gif', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
    '.woff2': 'font/woff2', '.mp4': 'video/mp4', '.mp3': 'audio/mpeg',
    '.zip': 'application/zip'
};

const SECURITY_HEADERS = {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' fonts.googleapis.com; font-src 'self' fonts.gstatic.com; img-src 'self' data: https://i.ytimg.com https://img.youtube.com; connect-src 'self' ws://localhost:8080 wss://localhost:8080 https://api.ipify.org; media-src 'self' blob:;",
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'Permissions-Policy': 'geolocation=(), microphone=(), camera=()'
};

// ==================== HTTP SERVER ====================
const httpServer = http.createServer((req, res) => {
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress;

    if (!ddosShield(req, req.socket)) return;
    if (isBlacklisted(ip, null)) { req.socket.destroy(); return; }
    if (!checkRateLimit(ip, 'http')) { res.writeHead(429); res.end('Too Many Requests'); return; }

    const url = req.url;
    const method = req.method;

    // ==================== API ROUTES (PROTEGIDAS) ====================
    // APIs só funcionam via WebSocket, MAS aqui temos endpoints para uso externo com API Key
    if (url.startsWith('/api/')) {
        handleApiRoute(req, res, url, method, ip);
        return;
    }

    // Serve downloads
    if (url.startsWith('/downloads/')) {
        const filePath = path.join(DOWNLOADS_DIR, path.basename(url));
        if (fs.existsSync(filePath)) {
            const ext = path.extname(filePath);
            res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream', ...SECURITY_HEADERS });
            fs.createReadStream(filePath).pipe(res);
        } else {
            res.writeHead(404); res.end('Not found');
        }
        return;
    }

    // Bloqueia métodos não-GET para arquivos estáticos
    if (method !== 'GET') { blacklist(ip, null, false); req.socket.destroy(); return; }

    // Serve arquivos estáticos
    let filePath = path.join(__dirname, 'public', url === '/' ? 'index.html' : url);
    const ext = path.extname(filePath).toLowerCase();
    if (!MIME_TYPES[ext]) filePath = path.join(__dirname, 'public', 'index.html');
    if (!fs.existsSync(filePath)) filePath = path.join(__dirname, 'public', 'index.html');

    fs.readFile(filePath, (err, data) => {
        if (err) { res.writeHead(500); res.end('Server Error'); return; }
        const headers = { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream', ...SECURITY_HEADERS };
        res.writeHead(200, headers);
        res.end(data);
    });
});

// ==================== API ROUTE HANDLER ====================
async function handleApiRoute(req, res, url, method, ip) {
    // CORS headers para APIs
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-API-Key');

    if (method === 'OPTIONS') { res.writeHead(200); res.end(); return; }

    // Parse query params
    const urlObj = new URL(url, `http://${req.headers.host}`);
    const params = Object.fromEntries(urlObj.searchParams);

    // Valida API Key
    const apiKey = req.headers['x-api-key'] || params.apikey;
    if (!apiKey || !apiKey.startsWith('valley_')) {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: false, msg: 'API Key inválida ou ausente' }));
        return;
    }

    // Verifica usuário e créditos
    const users = readDB(DB_USERS);
    const user = users.find(u => u.apiKey === apiKey);
    if (!user) {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: false, msg: 'API Key não encontrada' }));
        return;
    }
    if (user.credits < COST_PER_REQ) {
        res.writeHead(402, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: false, msg: 'Créditos insuficientes', credits: user.credits }));
        return;
    }

    // Deduz créditos
    user.credits -= COST_PER_REQ;
    const userIndex = users.findIndex(u => u.id === user.id);
    users[userIndex] = user;
    writeDB(DB_USERS, users);

    // Log de requisição
    const requests = readDB(DB_REQUESTS);
    requests.push({ id: crypto.randomUUID(), userId: user.id, endpoint: url, timestamp: new Date().toISOString(), ip });
    if (requests.length > 1000) requests.shift();
    writeDB(DB_REQUESTS, requests);

    // Roteamento de APIs
    try {
        let result;

        if (url.startsWith('/api/email/send')) {
            if (method !== 'POST') { res.writeHead(405); res.end(); return; }
            const body = await parseBody(req);
            result = await sendEmail(body);
        }
        else if (url.startsWith('/api/igstalk')) {
            if (!params.username) { result = { status: false, msg: 'Param username obrigatório' }; }
            else { result = await igStalk(params.username); }
        }
        else if (url.startsWith('/api/mediafire')) {
            if (!params.url) { result = { status: false, msg: 'Param url obrigatório' }; }
            else { result = await mediaFireDownload(params.url); }
        }
        else if (url.startsWith('/api/tiktok')) {
            if (!params.url) { result = { status: false, msg: 'Param url obrigatório' }; }
            else { result = await tiktokDownload(params.url, params.tipo || 'video'); }
        }
        else if (url.startsWith('/api/youtube/info')) {
            if (!params.q) { result = { status: false, msg: 'Param q obrigatório' }; }
            else { result = await youtubeInfo(params.q); }
        }
        else if (url.startsWith('/api/youtube')) {
            if (!params.url && !params.q) { result = { status: false, msg: 'Param url ou q obrigatório' }; }
            else { result = await youtubeDownload(params.url || params.q, params.tipo || 'audio'); }
        }
        else if (url.startsWith('/api/memory/save')) {
            if (!params.user || !params.key || !params.value) {
                result = { status: false, msg: 'Params user, key, value obrigatórios' };
            } else {
                result = memorySave(params.user, params.key, params.value);
            }
        }
        else if (url.startsWith('/api/memory/get')) {
            if (!params.user || !params.key) {
                result = { status: false, msg: 'Params user, key obrigatórios' };
            } else {
                result = memoryGet(params.user, params.key);
            }
        }
        else if (url.startsWith('/api/ai/text')) {
            // Simulado - Premium
            if (user.plan === 'free') {
                result = { status: false, msg: 'API Premium requer plano pago' };
            } else {
                result = { status: true, text: 'Resposta simulada da AI: ' + (params.prompt || 'Olá!') };
            }
        }
        else {
            result = { status: false, msg: 'Endpoint não encontrado' };
        }

        result.creditsRemaining = user.credits;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));

    } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: false, msg: err.message, creditsRemaining: user.credits }));
    }
}

function parseBody(req) {
    return new Promise((resolve, reject) => {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try { resolve(JSON.parse(body)); } catch { resolve({}); }
        });
        req.on('error', reject);
    });
}

// ==================== WEBSOCKET SERVER ====================
const wss = new WebSocketServer({ port: WS_PORT });
const clients = new Map();

wss.on('connection', (ws, req) => {
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress;
    const clientId = crypto.randomUUID();

    if (!ddosShield(req, req.socket)) { ws.terminate(); return; }
    if (!checkRateLimit(ip, 'ws_conn')) { ws.terminate(); return; }

    clients.set(clientId, { ws, ip, authenticated: false, user: null, hid: null, attempts: 0 });

    ws.on('message', async (rawData) => {
        const client = clients.get(clientId);
        if (!client) return;

        if (!checkRateLimit(client.ip, client.hid || 'unknown')) {
            ws.send(JSON.stringify({ type: 'error', code: 'RATE_LIMITED', msg: 'Muitas requisições' }));
            return;
        }

        let data;
        try { data = JSON.parse(rawData.toString()); }
        catch { ws.send(JSON.stringify({ type: 'error', code: 'INVALID_JSON' })); return; }

        if (!data.type || typeof data.type !== 'string') {
            ws.send(JSON.stringify({ type: 'error', code: 'INVALID_TYPE' })); return;
        }

        if (data.type !== 'ping') {
            if (!validateDeviceInfo(data.deviceInfo)) {
                client.attempts++;
                if (client.attempts >= 3) { blacklist(client.ip, null, false); ws.terminate(); return; }
                ws.send(JSON.stringify({ type: 'error', code: 'INVALID_DEVICE' })); return;
            }
            client.hid = data.deviceInfo.hid;
            if (isBlacklisted(client.ip, client.hid)) { ws.terminate(); return; }
        }

        try {
            switch (data.type) {
                case 'ping': ws.send(JSON.stringify({ type: 'pong', time: Date.now() })); break;
                case 'auth_register': await handleRegister(ws, data, client); break;
                case 'auth_login': await handleLogin(ws, data, client); break;
                case 'auth_check': await handleAuthCheck(ws, data, client); break;
                case 'get_user_info': await handleGetUserInfo(ws, data, client); break;
                case 'get_projects': await handleGetProjects(ws, data, client); break;
                case 'get_apis': await handleGetApis(ws, data, client); break;
                case 'use_api': await handleUseApi(ws, data, client); break;
                case 'get_api_plans': await handleGetApiPlans(ws, data, client); break;
                case 'logout': await handleLogout(ws, data, client); break;
                case 'get_device_ips': await handleGetDeviceIPs(ws, data, client); break;
                default: ws.send(JSON.stringify({ type: 'error', code: 'UNKNOWN_TYPE' }));
            }
        } catch (err) {
            ws.send(JSON.stringify({ type: 'error', code: 'SERVER_ERROR' }));
        }
    });

    ws.on('close', () => clients.delete(clientId));
    ws.on('error', () => clients.delete(clientId));
});

// ==================== HANDLERS ====================
async function handleRegister(ws, data, client) {
    const lockKey = 'register_lock';
    if (!await acquireLock(lockKey, 3000)) {
        ws.send(JSON.stringify({ type: 'error', code: 'BUSY', msg: 'Servidor ocupado' }));
        return;
    }
    try {
        const { username, email, password, deviceInfo } = data;

        if (!isValidText(username, 30)) { ws.send(JSON.stringify({ type: 'error', code: 'INVALID_USERNAME', msg: 'Apenas letras e números' })); return; }
        if (!isValidEmail(email)) { ws.send(JSON.stringify({ type: 'error', code: 'INVALID_EMAIL' })); return; }
        if (!password || password.length < 6 || password.length > 100) { ws.send(JSON.stringify({ type: 'error', code: 'INVALID_PASSWORD' })); return; }
        if (!/^[a-zA-Z0-9!@#$%^&*._-]+$/.test(password)) { ws.send(JSON.stringify({ type: 'error', code: 'INVALID_PASSWORD_CHARS' })); return; }

        const users = readDB(DB_USERS);
        if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) { ws.send(JSON.stringify({ type: 'error', code: 'USERNAME_TAKEN' })); return; }
        if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) { ws.send(JSON.stringify({ type: 'error', code: 'EMAIL_TAKEN' })); return; }

        const salt = crypto.randomBytes(16).toString('hex');
        const passwordHash = hash(password + salt + JWT_SECRET);

        let apiKey = genApiKey();
        while (users.some(u => u.apiKey === apiKey)) apiKey = genApiKey();

        const newUser = {
            id: crypto.randomUUID(),
            username: username.toLowerCase(),
            displayName: username,
            email: email.toLowerCase(),
            passwordHash, salt, apiKey,
            credits: DEFAULT_CREDITS,
            plan: 'free',
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString(),
            hid: deviceInfo.hid,
            ip: client.ip,
            loginHistory: [{ ip: client.ip, hid: deviceInfo.hid, time: new Date().toISOString() }]
        };

        users.push(newUser);
        writeDB(DB_USERS, users);

        const token = genToken();
        const sessions = readDB(DB_SESSIONS);
        sessions.push({ token: hash(token + JWT_SECRET), userId: newUser.id, ip: client.ip, hid: deviceInfo.hid, createdAt: new Date().toISOString(), expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() });
        writeDB(DB_SESSIONS, sessions);

        client.authenticated = true;
        client.user = newUser;

        ws.send(JSON.stringify({ type: 'register_success', token, user: { username: newUser.displayName, apiKey: newUser.apiKey, credits: newUser.credits, plan: newUser.plan } }));
    } finally { releaseLock(lockKey); }
}

async function handleLogin(ws, data, client) {
    const { username, password, deviceInfo } = data;
    if ((!isValidText(username, 30) && !isValidEmail(username)) || !password || password.length > 100) {
        ws.send(JSON.stringify({ type: 'error', code: 'INVALID_CREDENTIALS', msg: 'Credenciais inválidas' })); return;
    }

    const users = readDB(DB_USERS);
    const user = users.find(u => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === username.toLowerCase());

    if (!user) { crypto.randomBytes(32); ws.send(JSON.stringify({ type: 'error', code: 'INVALID_CREDENTIALS' })); return; }

    const passwordHash = hash(password + user.salt + JWT_SECRET);
    if (passwordHash !== user.passwordHash) { ws.send(JSON.stringify({ type: 'error', code: 'INVALID_CREDENTIALS' })); return; }

    user.lastLogin = new Date().toISOString();
    user.loginHistory.push({ ip: client.ip, hid: deviceInfo.hid, time: new Date().toISOString() });
    if (user.loginHistory.length > 10) user.loginHistory.shift();
    writeDB(DB_USERS, users);

    const token = genToken();
    const sessions = readDB(DB_SESSIONS);
    sessions.push({ token: hash(token + JWT_SECRET), userId: user.id, ip: client.ip, hid: deviceInfo.hid, createdAt: new Date().toISOString(), expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() });
    writeDB(DB_SESSIONS, sessions);

    client.authenticated = true;
    client.user = user;

    ws.send(JSON.stringify({ type: 'login_success', token, user: { username: user.displayName, apiKey: user.apiKey, credits: user.credits, plan: user.plan } }));
}

async function handleAuthCheck(ws, data, client) {
    const { token, deviceInfo } = data;
    if (!token || token.length !== 64) { ws.send(JSON.stringify({ type: 'auth_check', authenticated: false })); return; }

    const sessions = readDB(DB_SESSIONS);
    const session = sessions.find(s => s.token === hash(token + JWT_SECRET));
    if (!session || new Date(session.expiresAt) < new Date() || session.hid !== deviceInfo.hid) {
        ws.send(JSON.stringify({ type: 'auth_check', authenticated: false })); return;
    }

    const users = readDB(DB_USERS);
    const user = users.find(u => u.id === session.userId);
    if (!user) { ws.send(JSON.stringify({ type: 'auth_check', authenticated: false })); return; }

    client.authenticated = true;
    client.user = user;
    ws.send(JSON.stringify({ type: 'auth_check', authenticated: true, user: { username: user.displayName, apiKey: user.apiKey, credits: user.credits, plan: user.plan } }));
}

async function handleGetUserInfo(ws, data, client) {
    if (!client.authenticated || !client.user) { ws.send(JSON.stringify({ type: 'error', code: 'UNAUTHORIZED' })); return; }
    const users = readDB(DB_USERS);
    const user = users.find(u => u.id === client.user.id);
    if (!user) { ws.send(JSON.stringify({ type: 'error', code: 'USER_NOT_FOUND' })); return; }
    ws.send(JSON.stringify({ type: 'user_info', user: { username: user.displayName, apiKey: user.apiKey, credits: user.credits, plan: user.plan, createdAt: user.createdAt } }));
}

async function handleGetProjects(ws, data, client) {
    if (!client.authenticated) { ws.send(JSON.stringify({ type: 'error', code: 'UNAUTHORIZED' })); return; }
    const projects = readDB(DB_PROJECTS);
    ws.send(JSON.stringify({ type: 'projects', projects }));
}

async function handleGetApis(ws, data, client) {
    if (!client.authenticated) { ws.send(JSON.stringify({ type: 'error', code: 'UNAUTHORIZED' })); return; }
    const apis = readDB(DB_APIS);
    ws.send(JSON.stringify({ type: 'apis', apis }));
}

async function handleUseApi(ws, data, client) {
    if (!client.authenticated || !client.user) { ws.send(JSON.stringify({ type: 'error', code: 'UNAUTHORIZED' })); return; }

    const { apiId } = data;
    if (!isValidText(apiId, 20)) { ws.send(JSON.stringify({ type: 'error', code: 'INVALID_API' })); return; }

    const lockKey = `api_use_${client.user.id}`;
    if (!await acquireLock(lockKey, 3000)) { ws.send(JSON.stringify({ type: 'error', code: 'BUSY' })); return; }

    try {
        const users = readDB(DB_USERS);
        const userIndex = users.findIndex(u => u.id === client.user.id);
        if (userIndex === -1) { ws.send(JSON.stringify({ type: 'error', code: 'USER_NOT_FOUND' })); return; }

        const user = users[userIndex];
        if (user.credits < COST_PER_REQ) { ws.send(JSON.stringify({ type: 'error', code: 'NO_CREDITS' })); return; }

        const apis = readDB(DB_APIS);
        const api = apis.find(a => a.id === apiId);
        if (!api) { ws.send(JSON.stringify({ type: 'error', code: 'API_NOT_FOUND' })); return; }
        if (api.premium && user.plan === 'free') { ws.send(JSON.stringify({ type: 'error', code: 'PREMIUM_REQUIRED' })); return; }

        user.credits -= COST_PER_REQ;
        users[userIndex] = user;
        writeDB(DB_USERS, users);

        const requests = readDB(DB_REQUESTS);
        requests.push({ id: crypto.randomUUID(), userId: user.id, apiId, timestamp: new Date().toISOString(), ip: client.ip, hid: client.hid });
        if (requests.length > 1000) requests.shift();
        writeDB(DB_REQUESTS, requests);

        client.user = user;
        ws.send(JSON.stringify({ type: 'api_used', apiId, creditsRemaining: user.credits, result: { status: 'success', data: `Resposta da ${api.name}` } }));
    } finally { releaseLock(lockKey); }
}

async function handleGetApiPlans(ws, data, client) {
    if (!client.authenticated) { ws.send(JSON.stringify({ type: 'error', code: 'UNAUTHORIZED' })); return; }
    const plans = [
        { id: 'free', name: 'Free', price: 0, credits: 100, requests: 10, features: ['Acesso básico', 'APIs públicas', 'Suporte comunitário'] },
        { id: 'starter', name: 'Starter', price: 9.99, credits: 1000, requests: 100, features: ['Tudo do Free', 'APIs premium básicas', 'Suporte email'] },
        { id: 'pro', name: 'Pro', price: 29.99, credits: 5000, requests: 500, features: ['Tudo do Starter', 'Todas as APIs', 'Prioridade', 'Analytics'] },
        { id: 'enterprise', name: 'Enterprise', price: 99.99, credits: 50000, requests: 5000, features: ['Tudo do Pro', 'API customizada', 'Suporte 24/7', 'SLA garantido'] }
    ];
    ws.send(JSON.stringify({ type: 'api_plans', plans }));
}

async function handleLogout(ws, data, client) {
    const { token } = data;
    if (token) {
        const sessions = readDB(DB_SESSIONS);
        const filtered = sessions.filter(s => s.token !== hash(token + JWT_SECRET));
        writeDB(DB_SESSIONS, filtered);
    }
    client.authenticated = false;
    client.user = null;
    ws.send(JSON.stringify({ type: 'logout_success' }));
}

async function handleGetDeviceIPs(ws, data, client) {
    if (!client.authenticated) { ws.send(JSON.stringify({ type: 'error', code: 'UNAUTHORIZED' })); return; }

    // IP local (Wi-Fi) vs IP público (Internet)
    const publicIP = client.ip;

    ws.send(JSON.stringify({
        type: 'device_ips',
        localIP: 'Detectado no navegador',
        publicIP: publicIP,
        note: 'O IP local (Wi-Fi) é detectado via WebRTC no frontend'
    }));
}

// ==================== INICIA SERVIDORES ====================
httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`[VALLEY] HTTP Server: http://0.0.0.0:${PORT}`);
    console.log(`[VALLEY] WebSocket: ws://0.0.0.0:${WS_PORT}`);
    console.log(`[VALLEY] APIs ativas: /api/email, /api/igstalk, /api/mediafire, /api/tiktok, /api/youtube, /api/memory`);
    console.log(`[VALLEY] Data dir: ${DATA_DIR}`);
});

process.on('SIGINT', () => {
    console.log('\n[VALLEY] Encerrando...');
    wss.close();
    httpServer.close();
    process.exit(0);
});
